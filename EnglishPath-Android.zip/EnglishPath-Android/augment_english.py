"""Bilingual field augmentation; run after generate_content.py, without internet."""
import json
from pathlib import Path
p=Path(__file__).parent/'app/src/main/assets/curriculum.json'
d=json.loads(p.read_text())
rules=[
"Use I am, he/she/it is, and you/we/they are to describe identity, qualities, and location.",
"Nouns name people and things. Use a/an for singular count nouns and add -s/-es for regular plurals.",
"Use my, your, his, her, our and their to show possession. Use this/these for near and that/those for far.",
"Use Simple Present for routines and facts. Add -s/-es to most verbs after he, she or it.",
"Use do/does for Simple Present negatives and questions. Always use the base verb after does.",
"Use am/is/are with a verb ending in -ing for actions occurring now or temporarily.",
"Use there is for one or uncountable things, there are for plural things, and prepositions for location.",
"Adjectives modify nouns. Adverbs modify actions and express frequency, manner, or time.",
"Wh- questions request specific information; imperatives generally begin with a base verb.",
"Use Simple Past to describe completed past events. After did, use a base verb.",
"Was and were are past forms of be. Use was for I/he/she/it and were for you/we/they.",
"Past Continuous uses was/were + -ing for actions in progress at a past time.",
"Will expresses predictions or immediate decisions; be going to expresses plans or evidence-based predictions.",
"Countable and uncountable nouns take different quantifiers: many/few versus much/little.",
"Comparatives compare two things; superlatives describe one extreme in a group.",
"Use can for ability, should for advice, and must or have to for obligation. Follow modals with base verbs.",
"Present Perfect uses have/has + past participle to connect experiences or results to the present.",
"Some verbs are followed by -ing (enjoy reading); others by to + verb (want to read).",
"Use Simple Past with completed past time references and Present Perfect when the exact past time is unspecified.",
"Present Perfect Continuous (have/has been + -ing) focuses on an activity's duration up to now.",
"Past Perfect (had + past participle) identifies the earlier of two past actions.",
"Zero conditionals express facts; first conditionals express likely future possibilities.",
"Second conditionals express imaginary or unlikely present/future situations: if + past, would + verb.",
"Defining relative clauses identify who or what is meant using who, which, that or whose.",
"Use be + past participle in passive sentences to focus on the action or its result.",
"Reported speech describes another person's words, often shifting tense back in past reports.",
"Use conjunctions to combine ideas. Although introduces a clause; despite introduces a noun or -ing form.",
"Past Perfect Continuous (had been + -ing) stresses the duration of an action before a past event.",
"Third conditionals imagine different past outcomes; mixed conditionals connect past conditions with present results.",
"Modal + have + past participle can express past deductions, regret, or possibility.",
"Passive structures work across tenses and modals: is being done, has been done, must be done.",
"Non-defining relative clauses add extra information between commas and do not normally use that.",
"Wish + past describes unreal present situations; wish + had + past participle expresses past regrets.",
"Causative have/get + object + past participle describes arranging for an action to be done.",
"Reporting verbs take different patterns; indirect questions use statement word order.",
"Phrasal verbs have idiomatic meanings; collocations are word combinations that naturally occur together.",
"A negative adverbial at the beginning of a formal clause often triggers auxiliary-subject inversion.",
"Cleft structures emphasize one part of the sentence using It was... that or What... is.",
"Reduced relative clauses and participle clauses make sentences shorter while preserving information.",
"Nominalisation turns verbs or adjectives into nouns, a common feature of academic register.",
"Academic hedging expresses appropriate uncertainty, for example may suggest or appears to indicate.",
"Formal recommendations can take a subjunctive base verb: It is essential that she be ready.",
"Discourse markers connect claims, contrasts, causes and conclusions coherently.",
"Future Continuous uses will be + -ing; Future Perfect uses will have + past participle.",
"Ellipsis and substitution avoid repetition, while register adapts language to the audience."
]
assert len(rules)==45
cats=["Sentence basics","Nouns and articles","Possession","Habits and facts","Auxiliaries","Ongoing actions","Existence and location","Descriptions","Questions and commands","The past","Past be","Ongoing past actions","Plans and predictions","Quantity","Comparison","Modals","Experiences and outcomes","Verb patterns","Time references","Duration","Earlier past events","Real conditions","Imagined situations","Relative clauses","Action focus","Reported speech","Connecting ideas","Earlier duration","Past regrets","Past modal meaning","Passive tenses","Extra information","Unreal wishes","Causing actions","Reporting and questions","Natural expressions","Formal emphasis","Information focus","Condensed clauses","Academic style","Cautious statements","Formal structures","Coherence","Future time","Natural language"]
assert len(cats)==45
subs=["Build your English foundation","Talk about routines, the past, and plans","Connect ideas and experiences","Communicate with precision","Use complex structures naturally"]
for i,l in enumerate(d['levels']):l['subtitle_en']=subs[i]
for i,l in enumerate(d['lessons']):
    l['overview_en']=rules[i];l['category_en']=cats[i]
    l['mistake']['explanation_en']=rules[i]
    for q in l['questions']:
        s=q['prompt'].replace('Kalimat manakah yang benar secara tata bahasa?', 'Which sentence is grammatically correct?').replace('Lengkapi:','Complete:').replace('Pilih kalimat yang paling tepat sesuai materi.','Choose the best sentence for this topic.')
        for k,v in {'dekat, tunggal':'near, singular','di dalam':'inside','di atas':'on top of','tidak pernah':'never','buka':'open','sedikit, tidak spesifik dalam pertanyaan':'an unspecified amount in a question','am → lampau':'am → past','meskipun begitu':'nevertheless'}.items():
            s=s.replace('('+k+')','('+v+')')
        q['prompt_en']=s
        q['explanation_en']=f"Correct answer: {q['answer']}. {rules[i]}"
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('English fields added to',len(d['lessons']),'lessons')
