package com.englishpath.app

import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.graphics.vector.ImageVector
import java.util.Locale

internal val Ink = Color(0xFF18213D)
internal val Muted = Color(0xFF738099)
internal val Background = Color(0xFFF7F8FD)
internal val Violet = Color(0xFF6555DA)
internal val VioletPale = Color(0xFFEFEDFF)
internal val Green = Color(0xFF159B79)
internal val GreenPale = Color(0xFFE7F8F1)
internal val Red = Color(0xFFD4505D)
internal val RedPale = Color(0xFFFFEEF0)
internal val Border = Color(0xFFE7EAF3)

private fun hexColor(s: String): Color = Color(AndroidColor.parseColor(s))
private enum class Tab { HOME, PATH, PRACTICE, PROFILE }
internal val LocalLanguage = compositionLocalOf { "id" }
@Composable
internal fun loc(id: String, en: String): String = if (LocalLanguage.current == "id") id else en
private enum class Screen { MAIN, LESSON, QUIZ, RESULT, PLACEMENT, PLACEMENT_RESULT, SKILL }

internal class Speaker(context: android.content.Context) {
    private var ready = false
    private val engine: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
    }
    fun say(s: String) {
        if (ready) {
            engine.language = Locale.US
            engine.speak(s, TextToSpeech.QUEUE_FLUSH, null, "lesson_audio")
        }
    }
    fun shutdown() = engine.shutdown()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EnglishPathApp() }
    }
}

@Composable
private fun EnglishPathApp() {
    val context = LocalContext.current
    val course = remember { CourseRepository.load(context) }
    val store = remember { ProgressStore(context) }
    val speaker = remember { Speaker(context) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }

    var refresh by remember { mutableIntStateOf(0) }
    val completed = remember(refresh) { store.completedIds() }
    var language by remember { mutableStateOf(store.language()) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var screen by remember { mutableStateOf(if (store.placementCompleted()) Screen.MAIN else Screen.PLACEMENT) }
    var placementItems by remember { mutableStateOf(Placement.questions(course)) }
    var placementIndex by remember { mutableIntStateOf(-1) }
    var placementChoice by remember { mutableStateOf("") }
    var placementAnswers by remember { mutableStateOf<List<Boolean>>(emptyList()) }
    var chosenSkill by remember { mutableStateOf(Skill.READING) }
    var chosenSkillLevel by remember { mutableStateOf(store.placementLevel() ?: "A1") }
    var lesson by remember { mutableStateOf<Lesson?>(null) }
    var mixedLevel by remember { mutableStateOf("Semua") }
    var quizData by remember { mutableStateOf<List<Pair<Lesson, Exercise>>>(emptyList()) }
    var quizLessonId by remember { mutableStateOf<String?>(null) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var chosen by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf(false) }
    var correctCount by remember { mutableIntStateOf(0) }
    var incorrect by remember { mutableStateOf<List<SessionMistake>>(emptyList()) }
    var showExit by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }

    fun openLesson(item: Lesson) {
        lesson = item
        screen = Screen.LESSON
    }
    fun startQuiz(items: List<Pair<Lesson, Exercise>>, currentLessonId: String?) {
        quizData = items
        quizLessonId = currentLessonId
        quizIndex = 0
        chosen = ""
        checked = false
        correctCount = 0
        incorrect = emptyList()
        screen = Screen.QUIZ
    }
    fun finishQuiz() {
        store.recordSession(quizLessonId, correctCount, quizData.size)
        refresh += 1
        screen = Screen.RESULT
    }
    fun finishPlacement(skipped: Boolean = false) {
        val level = if (skipped) "A1" else Placement.recommend(placementItems, placementAnswers)
        store.savePlacement(level, if (skipped) -1 else placementAnswers.count { it }, placementItems.size)
        chosenSkillLevel = level
        refresh++
        screen = if (skipped) Screen.MAIN else Screen.PLACEMENT_RESULT
    }
    BackHandler(screen != Screen.MAIN && screen != Screen.PLACEMENT && screen != Screen.PLACEMENT_RESULT) {
        when (screen) {
            Screen.LESSON -> screen = Screen.MAIN
            Screen.QUIZ -> showExit = true
            Screen.RESULT -> screen = Screen.MAIN
            Screen.SKILL -> screen = Screen.MAIN
            else -> Unit
        }
    }

    CompositionLocalProvider(LocalLanguage provides language) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Violet, onPrimary = Color.White,
            background = Background, surface = Color.White, onSurface = Ink,
            outline = Border, error = Red),
        typography = Typography()
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize().safeDrawingPadding(),
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            containerColor = Background,
            bottomBar = {
                if (screen == Screen.MAIN) {
                    NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
                        navItems().forEach { (destination, label, icon) ->
                            NavigationBarItem(
                                selected = tab == destination,
                                onClick = { tab = destination },
                                icon = { Icon(icon, contentDescription = null) },
                                label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Violet, selectedTextColor = Violet,
                                    indicatorColor = VioletPale, unselectedIconColor = Muted,
                                    unselectedTextColor = Muted)
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    Screen.MAIN -> when (tab) {
                        Tab.HOME -> HomePage(course, store, completed, onLesson = ::openLesson,
                            onPath = { tab = Tab.PATH }, onPractice = { tab = Tab.PRACTICE })
                        Tab.PATH -> PathPage(course, store, completed, onLesson = ::openLesson)
                        Tab.PRACTICE -> PracticePage(course, mixedLevel,
                            onLevel = { mixedLevel = it },
                            onStart = {
                                val pool = course.lessons.filter { mixedLevel == "Semua" || it.level == mixedLevel }
                                    .flatMap { item -> item.questions.map { q -> item to q } }
                                startQuiz(pool.shuffled().take(10), null)
                            }, onSkill = { skill, level ->
                                chosenSkill = skill; chosenSkillLevel = level; screen = Screen.SKILL
                            }, recommended = store.placementLevel() ?: "A1")
                        Tab.PROFILE -> ProfilePage(course, store, completed,
                            language = language, onLanguage = { language = it; store.setLanguage(it) },
                            onRetest = {
                                placementItems = Placement.questions(course)
                                placementIndex = -1; placementChoice = ""; placementAnswers = emptyList()
                                screen = Screen.PLACEMENT
                            }, onReset = { showReset = true })
                    }
                    Screen.LESSON -> lesson?.let { item ->
                        LessonPage(item, course, store, speaker::say,
                            onBack = { screen = Screen.MAIN },
                            onStart = { startQuiz(item.questions.map { item to it }, item.id) })
                    }
                    Screen.QUIZ -> if (quizIndex in quizData.indices) {
                        val exercise = quizData[quizIndex].second
                        QuizPage(
                            index = quizIndex,
                            total = quizData.size,
                            title = if (quizLessonId == null) loc(loc("Latihan campuran", "Mixed practice"),"Mixed practice") else lesson?.title ?: "Latihan",
                            question = exercise,
                            response = chosen,
                            checked = checked,
                            onResponse = { if (!checked) chosen = it },
                            onBack = { showExit = true },
                            onAction = {
                                if (!checked) {
                                    if (chosen.isNotBlank()) {
                                        val right = exercise.isCorrect(chosen)
                                        if (right) correctCount += 1
                                        else incorrect = incorrect + SessionMistake(
                                            if (language=="id") exercise.prompt else exercise.promptEn, chosen, exercise.answer,
                                            if (language=="id") exercise.explanation else exercise.explanationEn)
                                        checked = true
                                    }
                                } else if (quizIndex == quizData.lastIndex) {
                                    finishQuiz()
                                } else {
                                    quizIndex += 1
                                    chosen = ""
                                    checked = false
                                }
                            }
                        )
                    }
                    Screen.RESULT -> ResultPage(
                        correct = correctCount, total = quizData.size,
                        errors = incorrect, isLesson = quizLessonId != null,
                        onRetry = { startQuiz(quizData.shuffled(), quizLessonId) },
                        onDone = { screen = Screen.MAIN }
                    )
                    Screen.PLACEMENT -> PlacementPage(
                        items = placementItems, index = placementIndex, selected = placementChoice,
                        onStart = { placementIndex = 0 }, onSkip = { finishPlacement(skipped = true) },
                        onLanguage = { language = if(language=="id") "en" else "id"; store.setLanguage(language) },
                        onChoice = { placementChoice = it },
                        onNext = {
                            if (placementChoice.isNotBlank()) {
                                val (_, question) = placementItems[placementIndex]
                                placementAnswers = placementAnswers + question.isCorrect(placementChoice)
                                placementChoice = ""
                                if (placementIndex == placementItems.lastIndex) finishPlacement()
                                else placementIndex++
                            }
                        }
                    )
                    Screen.PLACEMENT_RESULT -> PlacementResultPage(store.placementLevel() ?: "A1",
                        store.placementScore() ?: "0/20") { tab = Tab.PATH; screen = Screen.MAIN }
                    Screen.SKILL -> SkillPracticePage(chosenSkill, chosenSkillLevel, speaker::say,
                        onBack = { screen = Screen.MAIN }, onComplete = {
                            store.recordSkillActivity(chosenSkill); refresh++; screen = Screen.MAIN
                        })
                }
            }
        }
        if (showExit) {
            AlertDialog(
                onDismissRequest = { showExit = false },
                icon = { Icon(Icons.Default.Info, null, tint = Violet) },
                title = { Text(loc("Keluar dari latihan?","Leave the exercise?")) },
                text = { Text(loc("Jawaban dalam sesi ini belum disimpan.","Answers from this session have not been saved.")) },
                confirmButton = {
                    TextButton(onClick = {
                        showExit = false
                        screen = if (quizLessonId != null) Screen.LESSON else Screen.MAIN
                    }) { Text(loc("Keluar","Exit"), color = Red) }
                },
                dismissButton = { TextButton(onClick = { showExit = false }) { Text(loc("Lanjut latihan","Continue practice")) } }
            )
        }
        if (showReset) {
            AlertDialog(onDismissRequest = { showReset = false },
                title = { Text(loc("Hapus semua progres?","Delete all progress?")) },
                text = { Text(loc("Level yang selesai, nilai, XP, dan streak akan direset. Tidak dapat dibatalkan.","Completed lessons, scores, XP, and streak will be reset permanently.")) },
                confirmButton = { TextButton(onClick = { store.clear(course); refresh++; showReset = false }) {
                    Text(loc("Hapus progres","Delete progress"), color = Red)
                } },
                dismissButton = { TextButton(onClick = { showReset = false }) { Text(loc("Batal","Cancel")) } }
            )
        }
    }
    }
}

@Composable
private fun navItems(): List<Triple<Tab,String,ImageVector>> = listOf(
    Triple(Tab.HOME,loc("Beranda","Home"),Icons.Default.Home),
    Triple(Tab.PATH,loc("Materi","Lessons"),Icons.Default.MenuBook),
    Triple(Tab.PRACTICE,loc("Latihan","Practice"),Icons.Default.EditNote),
    Triple(Tab.PROFILE,loc("Progres","Progress"),Icons.Default.BarChart)
)

@Composable
internal fun SectionHeader(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
        }
        trailing?.invoke()
    }
}

@Composable
internal fun LabelChip(text: String, color: Color = Violet, bg: Color = VioletPale) {
    Surface(shape = RoundedCornerShape(12.dp), color = bg) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

@Composable
internal fun ProgressTrack(progress: Float, color: Color = Violet, track: Color = Border,
                          modifier: Modifier = Modifier) {
    LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = modifier.fillMaxWidth()
        .height(7.dp).clip(CircleShape), color = color, trackColor = track, gapSize = 0.dp,
        drawStopIndicator = {})
}

@Composable
private fun MetricCard(icon: ImageVector, value: String, label: String, color: Color,
                       modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = Color.White, shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Border)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
            Text(value, color = Ink, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
            Text(label, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun LessonRow(item: Lesson, position: Int, completed: Boolean, score: Int,
                      accent: Color, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable { onClick() },
        color = Color.White, shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Border)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(
                if (completed) GreenPale else accent.copy(alpha = 0.11f)),
                contentAlignment = Alignment.Center) {
                if (completed) Icon(Icons.Default.CheckCircle, null, tint = Green)
                else Text(position.toString().padStart(2,'0'), color = accent,
                    fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Ink, maxLines = 2,
                    overflow = TextOverflow.Ellipsis)
                Text("${if(LocalLanguage.current=="id") item.category else item.categoryEn}  •  ${item.minutes} ${loc("menit", "min")}", fontSize = 11.sp, color = Muted)
                if (score > 0) Text("Nilai terbaik $score%", fontSize = 11.sp,
                    fontWeight = FontWeight.Medium, color = Green)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun HomePage(course: Course, store: ProgressStore, completed: Set<String>,
                     onLesson: (Lesson) -> Unit, onPath: () -> Unit, onPractice: () -> Unit) {
    val total = course.lessons.size
    val next = course.lessons.firstOrNull { it.level == (store.placementLevel() ?: "A1") && it.id !in completed }
        ?: course.lessons.firstOrNull { it.id !in completed } ?: course.lessons.first()
    val levelInfo = course.levels.first { it.id == next.level }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("ENGLISHPATH", color = Violet, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(loc("Belajar sedikit,\nmahir bertahap.","Small steps,\nstronger English."), color = Ink, fontWeight = FontWeight.ExtraBold,
                        lineHeight = 32.sp, fontSize = 27.sp)
                }
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(17.dp)).background(VioletPale),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.School, null, tint = Violet, modifier = Modifier.size(28.dp))
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF7968F0),Color(0xFF5142BD))))) {
                Box(Modifier.align(Alignment.TopEnd).offset(x=39.dp, y=(-47).dp).size(150.dp)
                    .border(21.dp, Color.White.copy(alpha=0.09f), CircleShape))
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    LabelChip("JALUR BELAJAR • ${next.level}", Color.White, Color.White.copy(alpha=0.18f))
                    Text(loc("Siap untuk topik berikutnya?", "Ready for your next topic?"), fontWeight = FontWeight.Bold,
                        fontSize = 20.sp, color = Color.White)
                    Text(next.title, color = Color.White.copy(alpha=0.94f), fontSize = 14.sp)
                    Text(if(LocalLanguage.current=="id") "${completed.size} dari $total pelajaran selesai" else "${completed.size} of $total lessons completed", color = Color.White.copy(alpha=0.85f),fontSize=12.sp)
                    ProgressTrack(completed.size.toFloat()/total, Color.White, Color.White.copy(alpha=0.25f))
                    Button(onClick = { onLesson(next) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Violet),
                        shape = RoundedCornerShape(14.dp)) {
                        Text(loc("Mulai belajar", "Start learning"), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(Icons.Default.LocalFireDepartment, store.streak().toString(), loc("Hari beruntun","Day streak"), Color(0xFFE3893C), Modifier.weight(1f))
                MetricCard(Icons.Default.Stars, store.xp().toString(), loc("Total XP","Total XP"), Violet, Modifier.weight(1f))
                MetricCard(Icons.Default.CheckCircle, completed.size.toString(), loc("Materi selesai","Lessons done"), Green, Modifier.weight(1f))
            }
        }
        item {
            SectionHeader(loc("Lanjutkan perjalanan","Continue learning"), loc("Topik sesuai urutan fondasi ke mahir","Topics from foundations to advanced"), trailing = {
                TextButton(onClick = onPath) { Text(loc("Lihat semua","View all"), color = Violet, fontSize = 12.sp) }
            })
        }
        items(course.lessons.dropWhile { it.id in completed }.take(3).ifEmpty { course.lessons.takeLast(3) }) { item ->
            LessonRow(item, course.lessons.indexOf(item)+1, item.id in completed,
                store.bestScore(item.id), hexColor(course.levels.first { it.id == item.level }.shade)) { onLesson(item) }
        }
        item {
            Surface(color = Color(0xFFE9F8F6), shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth().clickable(onClick = onPractice)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Psychology, null, tint = Color(0xFF118F85))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(loc(loc("Latihan campuran", "Mixed practice"),"Mixed practice"), fontWeight=FontWeight.Bold, color=Ink, fontSize=15.sp)
                        Text(loc("Uji beberapa struktur sekaligus","Practise several structures together"), color=Muted, fontSize=12.sp)
                    }
                    Icon(Icons.Default.ArrowForward, null, tint=Color(0xFF118F85))
                }
            }
        }
        item { Spacer(Modifier.height(2.dp)) }
    }
}

@Composable
private fun PathPage(course: Course, store: ProgressStore, completed: Set<String>,
                     onLesson: (Lesson) -> Unit) {
    var filter by remember { mutableStateOf(store.placementLevel() ?: "A1") }
    val level = course.levels.first { it.id == filter }
    val filtered = course.lessons.filter { it.level == filter }
    val done = filtered.count { it.id in completed }
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text(loc("Peta Belajar","Learning Path"), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text(loc("45 materi dari pemula hingga mahir","45 lessons from beginner to advanced"), fontSize = 13.sp, color = Muted)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                course.levels.forEach { l ->
                    val active = filter == l.id
                    Surface(modifier = Modifier.weight(1f).clickable { filter = l.id },
                        shape = RoundedCornerShape(12.dp),
                        color = if (active) hexColor(l.shade) else Color.White,
                        border = if (active) null else BorderStroke(1.dp, Border)) {
                        Text(l.id, modifier=Modifier.padding(vertical=12.dp), textAlign=TextAlign.Center,
                            fontSize=13.sp, fontWeight=FontWeight.Bold,
                            color=if (active) Color.White else Muted)
                    }
                }
            }
        }
        item {
            val accent=hexColor(level.shade)
            Surface(color = accent.copy(alpha=.10f), shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    LabelChip(level.id, accent, Color.White.copy(alpha=.75f))
                    Text(level.name, color=Ink, fontSize=21.sp, fontWeight=FontWeight.ExtraBold)
                    Text(level.subtitle, color=Muted, fontSize=12.sp)
                    Text("$done / ${filtered.size} materi selesai", color=Ink, fontSize=12.sp, fontWeight=FontWeight.SemiBold)
                    ProgressTrack(done.toFloat()/filtered.size, accent)
                }
            }
        }
        item { SectionHeader("Materi ${level.id}", "Pilih materi mana pun untuk dipelajari") }
        items(filtered) { item ->
            LessonRow(item, filtered.indexOf(item)+1, item.id in completed,
                store.bestScore(item.id),hexColor(level.shade)) { onLesson(item) }
        }
        item { Spacer(Modifier.height(5.dp)) }
    }
}

@Composable
private fun PracticePage(course: Course, level: String, onLevel: (String) -> Unit, onStart: () -> Unit,
                         onSkill: (Skill, String) -> Unit, recommended: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text(loc("Arena Latihan","Practice Arena"), color=Ink,fontWeight=FontWeight.ExtraBold,fontSize=28.sp)
        Text(loc("Latihan acak membantu kamu membedakan berbagai pola grammar di satu sesi.","Mixed practice helps you distinguish different grammar patterns."),
            fontSize=14.sp,color=Muted,lineHeight=21.sp)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF149B9C), Color(0xFF0A707D))))) {
            Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Psychology, null, tint=Color.White, modifier=Modifier.size(36.dp))
                Text("Mixed Grammar Challenge", color=Color.White, fontSize=21.sp,
                    fontWeight=FontWeight.ExtraBold)
                Text("10 soal acak • Pilihan ganda + isian singkat • Penjelasan tiap jawaban",
                    color=Color.White.copy(alpha=.87f),fontSize=13.sp,lineHeight=20.sp)
            }
        }
        SectionHeader(loc("Pilih tingkat","Select level"), loc("Bisa juga latihan lintas level","Mix levels if you prefer"))
        val options = listOf("Semua") + course.levels.map { it.id }
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            options.chunked(3).forEach { row ->
                Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    row.forEach { option ->
                        val active=level==option
                        Surface(modifier=Modifier.weight(1f).clickable { onLevel(option) },
                            shape=RoundedCornerShape(14.dp),
                            color=if(active) VioletPale else Color.White,
                            border=BorderStroke(1.dp,if(active) Violet else Border)) {
                            Text(option,modifier=Modifier.padding(vertical=14.dp),
                                color=if(active) Violet else Ink,textAlign=TextAlign.Center,
                                fontWeight=FontWeight.Bold,fontSize=13.sp)
                        }
                    }
                    repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Surface(color=Color.White, shape=RoundedCornerShape(18.dp), border=BorderStroke(1.dp,Border)) {
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
                Text("Cara penilaian", fontSize=14.sp, fontWeight=FontWeight.Bold,color=Ink)
                Text("• Setiap jawaban benar mendapat 10 XP.\n• Jawaban salah dijelaskan sebelum lanjut.\n• Latihan campuran tidak mengubah nilai materi.",
                    fontSize=13.sp,color=Muted,lineHeight=21.sp)
            }
        }
        PrimaryButton(loc("Mulai 10 soal", "Start 10 questions"), Icons.Default.ArrowForward, onStart)
        SectionHeader(loc("Empat Keterampilan", "Four Language Skills"),
            loc("Dua kegiatan per level pada setiap keterampilan", "Two tasks per level for each skill"))
        Skill.values().forEach { skill ->
            Surface(modifier = Modifier.fillMaxWidth().clickable { onSkill(skill, if(level=="Semua") recommended else level) },
                color = Color.White, shape=RoundedCornerShape(17.dp), border=BorderStroke(1.dp,Border)) {
                Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    val image = when(skill) {
                        Skill.READING -> Icons.Default.MenuBook
                        Skill.LISTENING -> Icons.Default.Headphones
                        Skill.WRITING -> Icons.Default.Create
                        Skill.SPEAKING -> Icons.Default.RecordVoiceOver
                    }
                    Icon(image,null,tint=Violet)
                    Column(Modifier.weight(1f)) {
                        Text(if(LocalLanguage.current=="id") skill.label else skill.nameEn, fontWeight=FontWeight.Bold,color=Ink)
                        Text(loc("Tingkat ${if(level=="Semua") recommended else level} · Latihan bertahap", "Level ${if(level=="Semua") recommended else level} · Guided practice"),fontSize=12.sp,color=Muted)
                    }
                    Icon(Icons.Default.ArrowForward,null,tint=Violet)
                }
            }
        }
    }
}

@Composable
private fun ProfilePage(course: Course, store: ProgressStore, completed: Set<String>,
                        language: String, onLanguage: (String) -> Unit, onRetest: () -> Unit,
                        onReset: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement=Arrangement.spacedBy(19.dp)) {
        Text("Progres Belajar", fontSize=28.sp, fontWeight=FontWeight.ExtraBold, color=Ink)
        Text(loc("Perkembanganmu tersimpan lokal di ponsel ini.","Your progress is stored locally on this device."),color=Muted,fontSize=13.sp)
        SectionHeader(loc("Bahasa aplikasi", "App language"))
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            listOf("id" to "Indonesia", "en" to "English").forEach { (code,label) ->
                FilterChip(selected=language==code, onClick={onLanguage(code)}, label={Text(label)},
                    leadingIcon={if(language==code) Icon(Icons.Default.Check,null,modifier=Modifier.size(17.dp))})
            }
        }
        Surface(color=VioletPale,shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text(loc("Level awal yang disarankan", "Suggested starting level"),fontSize=12.sp,color=Muted)
                Text("${store.placementLevel() ?: "A1"}  ·  ${store.placementScore()?.takeIf { !it.startsWith("-1/") } ?: loc("Tes dilewati", "Test skipped")}",fontWeight=FontWeight.Bold,color=Violet,fontSize=19.sp)
                Text(loc("Tes ini bersifat indikatif, bukan sertifikasi CEFR.","This is an informal screening, not a CEFR certificate."),fontSize=11.sp,color=Muted)
                TextButton(onClick=onRetest) { Text(loc("Ulangi tes penempatan", "Retake placement test")) }
            }
        }
        Surface(color=Ink,shape=RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(22.dp),verticalArrangement=Arrangement.spacedBy(13.dp)) {
                Text(loc("PENCAPAIAN BELAJAR","LEARNING ACHIEVEMENT"),color=Color.White.copy(alpha=.72f),fontSize=11.sp,
                    fontWeight=FontWeight.Bold,letterSpacing=1.sp)
                Text("${(100f*completed.size/course.lessons.size).toInt()}%",color=Color.White,
                    fontSize=42.sp,fontWeight=FontWeight.ExtraBold)
                Text(loc("${completed.size} dari ${course.lessons.size} topik telah dikuasai","${completed.size} of ${course.lessons.size} topics mastered"),color=Color.White.copy(alpha=.84f),fontSize=13.sp)
                ProgressTrack(completed.size.toFloat()/course.lessons.size,Color(0xFF6CE4CC),Color.White.copy(alpha=.24f))
            }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            MetricCard(Icons.Default.Stars,"${store.xp()}",loc("Total XP","Total XP"),Violet,Modifier.weight(1f))
            MetricCard(Icons.Default.LocalFireDepartment,"${store.streak()}",loc("Hari beruntun","Day streak"),Color(0xFFE3893C),Modifier.weight(1f))
            MetricCard(Icons.Default.Quiz,"${store.sessions()}",loc("Sesi latihan","Practice sessions"),Green,Modifier.weight(1f))
        }
        SectionHeader(loc("Penguasaan per level","Progress by level"))
        course.levels.forEach { l ->
            val matching = course.lessons.filter { it.level == l.id }
            val done=matching.count { it.id in completed }
            Surface(color=Color.White,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Border)) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        LabelChip(l.id,hexColor(l.shade),hexColor(l.shade).copy(alpha=.11f))
                        Spacer(Modifier.width(10.dp))
                        Text(l.name,color=Ink,fontSize=14.sp,fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                        Text("$done / ${matching.size}",color=Muted,fontSize=12.sp)
                    }
                    ProgressTrack(done.toFloat()/matching.size,hexColor(l.shade))
                }
            }
        }
        TextButton(onClick=onReset,modifier=Modifier.align(Alignment.CenterHorizontally)) {
            Icon(Icons.Default.RestartAlt,null,tint=Red)
            Spacer(Modifier.width(8.dp))
            Text(loc("Reset progres belajar","Reset learning progress"),color=Red)
        }
    }
}

@Composable
internal fun PrimaryButton(label: String, icon: ImageVector, onClick: () -> Unit, enabled: Boolean = true,
                          color: Color = Violet) {
    Button(onClick=onClick, enabled=enabled, modifier=Modifier.fillMaxWidth().height(54.dp),
        shape=RoundedCornerShape(16.dp),
        colors=ButtonDefaults.buttonColors(containerColor=color,disabledContainerColor=Border)) {
        Text(label,fontWeight=FontWeight.Bold,fontSize=15.sp)
        Spacer(Modifier.width(8.dp))
        Icon(icon,null,modifier=Modifier.size(20.dp))
    }
}

@Composable
internal fun BackTitle(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        IconButton(onClick=onBack,modifier=Modifier.size(38.dp)) {
            Icon(Icons.Default.ArrowBack,contentDescription="Kembali",tint=Ink)
        }
        Spacer(Modifier.width(9.dp))
        Text(title,color=Ink,fontWeight=FontWeight.Bold,fontSize=16.sp,
            maxLines=1,overflow=TextOverflow.Ellipsis)
    }
}

@Composable
private fun LessonPage(item: Lesson, course: Course, store: ProgressStore, say: (String) -> Unit,
                       onBack: () -> Unit, onStart: () -> Unit) {
    val shade=hexColor(course.levels.first { it.id==item.level }.shade)
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal=20.dp, vertical=10.dp)) {
            BackTitle("Materi ${item.level}",onBack)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())
            .padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
            LabelChip("${item.level}  •  ${if(LocalLanguage.current=="id") item.category else item.categoryEn}", shade, shade.copy(alpha=.12f))
            Text(item.title,fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Ink,lineHeight=34.sp)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule,null,tint=Muted,modifier=Modifier.size(15.dp))
                Spacer(Modifier.width(5.dp))
                Text(loc("${item.minutes} menit membaca • 4 pertanyaan","${item.minutes} min reading • 4 questions"),fontSize=12.sp,color=Muted)
                val best=store.bestScore(item.id)
                if (best>0) { Spacer(Modifier.width(9.dp)); LabelChip("Terbaik $best%",Green,GreenPale) }
            }
            StudyCard("01", loc("Konsep","Concept"), Icons.Default.MenuBook, shade) {
                Text(if(LocalLanguage.current=="id") item.overview else item.overviewEn,color=Ink,fontSize=14.sp,lineHeight=23.sp)
            }
            StudyCard("02", loc("Pola / Rumus","Structure / Formula"), Icons.Default.AutoAwesome,shade) {
                Surface(color=VioletPale,shape=RoundedCornerShape(15.dp),modifier=Modifier.fillMaxWidth()) {
                    Text(item.formula,modifier=Modifier.padding(16.dp),color=Violet,
                        fontSize=15.sp,fontWeight=FontWeight.SemiBold,lineHeight=24.sp)
                }
            }
            StudyCard("03", loc("Contoh & Pengucapan","Examples & Pronunciation"), Icons.Default.RecordVoiceOver,shade) {
                item.examples.forEach { e ->
                    Surface(color=Background,shape=RoundedCornerShape(15.dp)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                                Text(e.en,color=Ink,fontSize=16.sp,fontWeight=FontWeight.SemiBold,lineHeight=23.sp)
                                Text(e.translation,color=Muted,fontSize=13.sp,lineHeight=19.sp)
                            }
                            IconButton(onClick={say(e.en)}) {
                                Icon(Icons.Default.VolumeUp,contentDescription="Dengarkan pengucapan",tint=Violet)
                            }
                        }
                    }
                }
                Text(loc("Ketuk ikon suara untuk mendengarkan pelafalan bahasa Inggris.","Tap the speaker icon to hear English pronunciation."),fontSize=11.sp,color=Muted)
            }
            StudyCard("04", loc("Kesalahan yang Sering Terjadi","Common Mistakes"), Icons.Default.TipsAndUpdates,shade) {
                Text("SALAH",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Red,letterSpacing=1.sp)
                Text(item.mistake.wrong,color=Red,fontSize=14.sp)
                Spacer(Modifier.height(7.dp))
                Text("BENAR",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Green,letterSpacing=1.sp)
                Text(item.mistake.right,color=Green,fontWeight=FontWeight.SemiBold,fontSize=14.sp)
                Spacer(Modifier.height(7.dp))
                Text(if(LocalLanguage.current=="id") item.mistake.explanation else item.mistake.explanationEn,color=Muted,fontSize=13.sp,lineHeight=20.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
        Surface(color=Color.White,shadowElevation=6.dp) {
            Column(Modifier.padding(16.dp)) {
                PrimaryButton(loc("Kerjakan 4 soal","Answer 4 questions"),Icons.Default.ArrowForward,onStart)
            }
        }
    }
}

@Composable
private fun StudyCard(num: String, heading: String, icon: ImageVector, accent: Color,
                      content: @Composable ColumnScope.() -> Unit) {
    Surface(color=Color.White,shape=RoundedCornerShape(21.dp),border=BorderStroke(1.dp,Border)) {
        Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(13.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(31.dp).clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha=.10f)),contentAlignment=Alignment.Center) {
                    Icon(icon,null,tint=accent,modifier=Modifier.size(17.dp))
                }
                Spacer(Modifier.width(10.dp))
                Text(heading,modifier=Modifier.weight(1f),fontSize=15.sp,fontWeight=FontWeight.Bold,color=Ink)
                Text(num,color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
private fun QuizPage(index: Int,total: Int,title: String,question: Exercise,response: String,checked: Boolean,
                     onResponse: (String) -> Unit,onBack: () -> Unit,onAction: () -> Unit) {
    val correct=checked && question.isCorrect(response)
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal=20.dp,vertical=10.dp), verticalArrangement=Arrangement.spacedBy(13.dp)) {
            BackTitle(title,onBack)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("SOAL ${index+1} DARI $total",color=Violet,fontWeight=FontWeight.ExtraBold,
                    fontSize=11.sp,letterSpacing=1.sp,modifier=Modifier.weight(1f))
                Text("${((index+1)*100/total)}%",color=Muted,fontSize=12.sp)
            }
            ProgressTrack((index+1f)/total)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement=Arrangement.spacedBy(17.dp)) {
            LabelChip(if (question.type == "input") loc("ISI JAWABAN","TYPE THE ANSWER") else loc("PILIHAN GANDA","MULTIPLE CHOICE"))
            Text(if(LocalLanguage.current=="id") question.prompt else question.promptEn,color=Ink,fontSize=23.sp,fontWeight=FontWeight.Bold,lineHeight=32.sp)
            Spacer(Modifier.height(5.dp))
            if (question.type=="choice") {
                question.options.forEachIndexed { optionIndex, option ->
                    val selected=option==response
                    val isAnswer=option==question.answer
                    val bg=when {
                        checked && isAnswer -> GreenPale
                        checked && selected -> RedPale
                        selected -> VioletPale
                        else -> Color.White
                    }
                    val stroke=when {
                        checked && isAnswer -> Green
                        checked && selected -> Red
                        selected -> Violet
                        else -> Border
                    }
                    Surface(modifier=Modifier.fillMaxWidth().clickable(enabled=!checked) { onResponse(option) },
                        color=bg, shape=RoundedCornerShape(18.dp),border=BorderStroke(1.5.dp,stroke)) {
                        Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically,
                            horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(31.dp).clip(RoundedCornerShape(9.dp))
                                .background(stroke.copy(alpha=.11f)),contentAlignment=Alignment.Center) {
                                Text(('A'+optionIndex).toString(),color=stroke,fontSize=12.sp,
                                    fontWeight=FontWeight.Bold)
                            }
                            Text(option,color=Ink,modifier=Modifier.weight(1f),fontSize=14.sp,lineHeight=21.sp)
                            if (checked && isAnswer) Icon(Icons.Default.CheckCircle,null,tint=Green,modifier=Modifier.size(20.dp))
                            else if (checked && selected) Icon(Icons.Default.Cancel,null,tint=Red,modifier=Modifier.size(20.dp))
                        }
                    }
                }
            } else {
                OutlinedTextField(value=response,onValueChange=onResponse,enabled=!checked,
                    modifier=Modifier.fillMaxWidth(),singleLine=true,
                    label={ Text(loc("Jawaban dalam bahasa Inggris","Answer in English")) },
                    placeholder={ Text(loc("Ketik jawaban...","Type your answer...")) },
                    keyboardOptions=KeyboardOptions(imeAction=ImeAction.Done),
                    keyboardActions=KeyboardActions(onDone={ if (!checked && response.isNotBlank()) onAction() }),
                    shape=RoundedCornerShape(17.dp),
                    colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Violet))
                Text(loc("Tulis kata atau frasa yang tepat. Huruf besar dan tanda baca tidak memengaruhi nilai.","Write the correct word or phrase. Capital letters and ending punctuation do not affect the score."),
                    fontSize=12.sp,color=Muted,lineHeight=19.sp)
            }
            if (checked) {
                Surface(color=if(correct) GreenPale else RedPale,shape=RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(if(correct) Icons.Default.CheckCircle else Icons.Default.Info,null,
                                tint=if(correct) Green else Red)
                            Spacer(Modifier.width(8.dp))
                            Text(if(correct) loc("Jawaban tepat!","Correct answer!") else loc("Belum tepat","Not quite"),fontSize=16.sp,
                                fontWeight=FontWeight.Bold,color=if(correct) Green else Red)
                        }
                        if(!correct) Text(loc("Jawaban benar: ${question.answer}","Correct answer: ${question.answer}"),fontSize=13.sp,
                            color=Ink,fontWeight=FontWeight.SemiBold)
                        Text(if(LocalLanguage.current=="id") question.explanation else question.explanationEn,color=Ink,fontSize=13.sp,lineHeight=21.sp)
                    }
                }
            }
        }
        Surface(color=Color.White,shadowElevation=6.dp) {
            Column(Modifier.padding(16.dp)) {
                PrimaryButton(if(!checked) loc("Periksa jawaban","Check answer") else if(index==total-1) loc("Lihat hasil","See results") else loc("Soal berikutnya","Next question"),
                    Icons.Default.ArrowForward,onAction, enabled=checked || response.isNotBlank(),
                    color=if(checked && correct) Green else Violet)
            }
        }
    }
}

@Composable
private fun ResultPage(correct: Int,total: Int,errors: List<SessionMistake>,isLesson: Boolean,
                       onRetry: () -> Unit,onDone: () -> Unit) {
    val percent=if(total==0) 0 else correct*100/total
    val mastered=percent>=75
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(18.dp))
        Box(Modifier.size(86.dp).clip(CircleShape).background(if(mastered) GreenPale else VioletPale),
            contentAlignment=Alignment.Center) {
            Icon(if(mastered) Icons.Default.EmojiEvents else Icons.Default.Psychology,
                null,tint=if(mastered) Green else Violet,modifier=Modifier.size(43.dp))
        }
        Text(if(mastered) loc("Kerja bagus!","Well done!") else loc("Terus berlatih!","Keep practising!"),fontSize=27.sp,
            fontWeight=FontWeight.ExtraBold,color=Ink)
        Text(loc("Kamu menjawab $correct dari $total soal dengan benar.","You answered $correct out of $total questions correctly."),color=Muted,fontSize=14.sp,
            textAlign=TextAlign.Center)
        Text("$percent%",fontSize=55.sp,fontWeight=FontWeight.ExtraBold,
            color=if(mastered) Green else Violet)
        ProgressTrack(percent/100f, if(mastered) Green else Violet)
        LabelChip("+${correct*10} XP",Green,GreenPale)
        if (isLesson) {
            Text(if(mastered) "Materi selesai! Kamu sudah memenuhi target minimal 75%."
            else "Butuh minimal 75% untuk menyelesaikan materi. Coba ulangi soal dan pelajari penjelasannya.",
                color=Muted,textAlign=TextAlign.Center,fontSize=13.sp,lineHeight=20.sp)
        }
        if(errors.isNotEmpty()) {
            Spacer(Modifier.height(5.dp))
            SectionHeader(loc("Ulas jawaban keliru","Review incorrect answers"), loc("Pahami penjelasannya sebelum mengulang","Review explanations before retrying"))
            errors.forEach { error ->
                Surface(color=Color.White,shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,Border)) {
                    Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                        Text(error.prompt,color=Ink,fontWeight=FontWeight.Bold,fontSize=14.sp)
                        Text(loc("Jawabanmu: ${error.yourAnswer}","Your answer: ${error.yourAnswer}"),color=Red,fontSize=12.sp)
                        Text(loc("Benar: ${error.correctAnswer}","Correct: ${error.correctAnswer}"),color=Green,fontSize=12.sp,fontWeight=FontWeight.SemiBold)
                        Text(error.explanation,color=Muted,fontSize=12.sp,lineHeight=19.sp)
                    }
                }
            }
        }
        PrimaryButton(loc("Ulangi soal","Retry questions"), Icons.Default.Replay,onRetry)
        OutlinedButton(onClick=onDone,modifier=Modifier.fillMaxWidth().height(52.dp),
            shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,Border)) {
            Text(loc("Kembali ke beranda","Return home"),color=Ink,fontWeight=FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
    }
}
