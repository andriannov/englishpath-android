package com.englishpath.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
internal fun PlacementPage(
    items: List<Pair<Lesson, Exercise>>, index: Int, selected: String,
    onStart: () -> Unit, onSkip: () -> Unit, onLanguage: () -> Unit,
    onChoice: (String) -> Unit, onNext: () -> Unit
) {
    if (index < 0) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.End) {
                OutlinedButton(onClick=onLanguage,shape=RoundedCornerShape(14.dp)) {
                    Text(if(LocalLanguage.current=="id") "English" else "Bahasa Indonesia")
                }
            }
            Spacer(Modifier.height(10.dp))
            Surface(shape=RoundedCornerShape(26.dp), color=VioletPale) {
                Icon(Icons.Default.School, null, tint=Violet, modifier=Modifier.padding(24.dp).size(54.dp))
            }
            Text(loc("Cari level belajarmu", "Discover your starting level"),fontSize=29.sp,
                fontWeight=FontWeight.ExtraBold, color=Ink,textAlign=TextAlign.Center)
            Text(loc("Tes awal membantu memilih materi yang sesuai dengan kemampuanmu.",
                "A quick screening helps you start with material suited to your current knowledge."),
                color=Muted,fontSize=15.sp,lineHeight=23.sp,textAlign=TextAlign.Center)
            Surface(color=Color.White,shape=RoundedCornerShape(20.dp),border=BorderStroke(1.dp,Border)) {
                Column(Modifier.fillMaxWidth().padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text(loc("20 soal · 5 tingkat · sekitar 10 menit", "20 questions · 5 bands · about 10 minutes"),
                        fontSize=15.sp,fontWeight=FontWeight.Bold,color=Ink)
                    Text(loc("Materi akan direkomendasikan dari A1 hingga C1. Tidak ada batas waktu. Hasil bersifat perkiraan, bukan sertifikasi resmi.",
                        "We'll recommend A1 through C1. There is no time limit. The result is an estimate, not an official certificate."),
                        color=Muted,lineHeight=21.sp,fontSize=13.sp)
                    Text(loc("Penilaian ini menguji grammar dan membaca kalimat singkat. Listening, writing, dan speaking dinilai melalui latihan tersendiri.",
                        "This screening checks grammar and short-sentence comprehension. Listening, writing and speaking are practised separately."),
                        color=Muted,lineHeight=21.sp,fontSize=12.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            PrimaryButton(loc("Mulai tes", "Begin test"), Icons.Default.ArrowForward, onStart)
            TextButton(onClick=onSkip) {
                Text(loc("Lewati dan mulai dari A1", "Skip and start at A1"), color=Muted)
            }
        }
        return
    }
    if (items.isEmpty() || index !in items.indices) return
    val item = items[index].second
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text(loc("TES PENEMPATAN", "PLACEMENT TEST"), color=Violet,
                fontWeight=FontWeight.Bold,fontSize=11.sp,letterSpacing=1.sp)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("${index+1} / ${items.size}",fontSize=16.sp,fontWeight=FontWeight.Bold,color=Ink,
                    modifier=Modifier.weight(1f))
                Text("${(index+1)*100/items.size}%",color=Muted)
            }
            LinearProgressIndicator(progress={ (index+1).toFloat()/items.size },modifier=Modifier.fillMaxWidth())
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement=Arrangement.spacedBy(15.dp)) {
            Text(if(LocalLanguage.current=="id") item.prompt else item.promptEn,
                fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink,lineHeight=31.sp)
            if(item.type=="choice") {
                item.options.forEach { option ->
                    val active=option==selected
                    Surface(modifier=Modifier.fillMaxWidth().clickable { onChoice(option) },
                        shape=RoundedCornerShape(16.dp),color=if(active) VioletPale else Color.White,
                        border=BorderStroke(1.5.dp,if(active) Violet else Border)) {
                        Text(option,modifier=Modifier.padding(16.dp),color=Ink,fontSize=15.sp)
                    }
                }
            } else {
                OutlinedTextField(value=selected,onValueChange=onChoice,modifier=Modifier.fillMaxWidth(),
                    label={Text(loc("Jawabanmu", "Your answer"))},singleLine=true,
                    shape=RoundedCornerShape(16.dp))
            }
            Text(loc("Jawaban dan hasil akan dievaluasi setelah soal terakhir.",
                "Answers are evaluated after the final question."),fontSize=12.sp,color=Muted)
        }
        Surface(color=Color.White, shadowElevation=4.dp) {
            Box(Modifier.padding(16.dp)) {
                PrimaryButton(if(index==items.lastIndex) loc("Selesaikan tes","Finish test") else loc("Lanjut","Continue"),
                    Icons.Default.ArrowForward,onNext,enabled=selected.isNotBlank())
            }
        }
    }
}

@Composable
internal fun PlacementResultPage(level: String, score: String, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(20.dp)) {
        Spacer(Modifier.height(35.dp))
        Icon(Icons.Default.CheckCircle,null,tint=Color(0xFF159B79),modifier=Modifier.size(66.dp))
        Text(loc("Tes selesai!","Test complete!"),fontSize=27.sp,fontWeight=FontWeight.ExtraBold,color=Ink)
        Text(loc("Tingkat belajar yang disarankan", "Recommended starting level"),color=Muted)
        Surface(shape=RoundedCornerShape(26.dp),color=VioletPale) {
            Text(level,color=Violet,fontSize=56.sp,fontWeight=FontWeight.ExtraBold,
                modifier=Modifier.padding(horizontal=50.dp,vertical=20.dp))
        }
        Text("$score ${loc("jawaban benar","correct answers")}",color=Ink,fontWeight=FontWeight.SemiBold)
        Text(loc("Rekomendasi berdasarkan pola jawaban di lima rentang kesulitan. Kamu dapat mempelajari level mana pun dan mengulang tes kapan saja.",
            "The recommendation is based on answers across five difficulty bands. You may study any level and retake the test later."),
            color=Muted,textAlign=TextAlign.Center,lineHeight=23.sp)
        Text(loc("Perkiraan nonstandar—bukan bukti resmi tingkat CEFR.",
            "Informal estimate—not an official CEFR qualification."),color=Muted,fontSize=12.sp,textAlign=TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        PrimaryButton(loc("Lihat jalur belajar","Open my learning path"),Icons.Default.ArrowForward,onContinue)
    }
}

private fun tokenMatch(reference: String, spoken: String): Int {
    fun words(x: String): List<String> = x.lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9' ]")," ").split(Regex("\\s+")).filter { it.isNotBlank() }
    val expected=words(reference)
    if(expected.isEmpty())return 0
    val remaining=words(spoken).toMutableList()
    var matched=0
    expected.forEach { token -> if(remaining.remove(token)) matched++ }
    return matched*100/expected.size
}

@Composable
internal fun SkillPracticePage(skill: Skill, level: String, say: (String) -> Unit,
                               onBack: () -> Unit,onComplete: () -> Unit) {
    val tasks = remember(skill,level) { SkillCatalog.tasks(skill).filter { it.level == level } }
    var index by remember(skill,level) { mutableIntStateOf(0) }
    var selected by remember(skill,level) { mutableStateOf("") }
    var revealed by remember(skill,level) { mutableStateOf(false) }
    var transcript by remember(skill,level) { mutableStateOf("") }
    var error by remember(skill,level) { mutableStateOf("") }
    val context=LocalContext.current
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if(result.resultCode==Activity.RESULT_OK) {
            val heard=result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if(!heard.isNullOrBlank()) { transcript=heard; revealed=true }
        }
    }
    if(tasks.isEmpty())return
    val item=tasks[index.coerceIn(tasks.indices)]
    fun advance() {
        if(index>=tasks.lastIndex) onComplete()
        else { index++; selected=""; revealed=false; transcript=""; error="" }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(13.dp)) {
            BackTitle(if(LocalLanguage.current=="id") skill.label else skill.nameEn, onBack)
            Row(verticalAlignment=Alignment.CenterVertically) {
                LabelChip(level)
                Spacer(Modifier.width(10.dp))
                Text("${index+1} / ${tasks.size}",color=Muted,fontSize=12.sp,modifier=Modifier.weight(1f))
                Text(loc("Latihan keterampilan","Skill practice"),color=Muted,fontSize=12.sp)
            }
            LinearProgressIndicator(progress={ (index+1).toFloat()/tasks.size },modifier=Modifier.fillMaxWidth())
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=20.dp),
            verticalArrangement=Arrangement.spacedBy(16.dp)) {
            Text(if(LocalLanguage.current=="id") item.titleId else item.title,
                fontWeight=FontWeight.ExtraBold,fontSize=25.sp,color=Ink)
            when(skill) {
                Skill.READING -> {
                    Surface(color=Color.White,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Border)) {
                        Text(item.text,modifier=Modifier.padding(20.dp),fontSize=17.sp,color=Ink,lineHeight=28.sp)
                    }
                    Text(if(LocalLanguage.current=="id") item.questionId else item.question,
                        fontSize=18.sp,fontWeight=FontWeight.Bold,color=Ink)
                }
                Skill.LISTENING -> {
                    Surface(color=VioletPale,shape=RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,
                            verticalArrangement=Arrangement.spacedBy(12.dp)) {
                            Icon(Icons.Default.Headphones,null,tint=Violet,modifier=Modifier.size(39.dp))
                            Text(loc("Dengarkan rekaman suara", "Listen to the spoken audio"),
                                color=Ink,fontWeight=FontWeight.SemiBold)
                            Button(onClick={say(item.text)},shape=RoundedCornerShape(14.dp)) {
                                Icon(Icons.Default.VolumeUp,null)
                                Spacer(Modifier.width(6.dp))
                                Text(loc("Putar / Ulangi", "Play / Repeat"))
                            }
                            if(revealed) Text(item.text,color=Ink,fontSize=15.sp,lineHeight=22.sp)
                            else Text(loc("Transkrip terbuka setelah memeriksa jawaban.","Transcript is revealed after checking."),
                                fontSize=12.sp,color=Muted,textAlign=TextAlign.Center)
                        }
                    }
                    Text(if(LocalLanguage.current=="id") item.questionId else item.question,
                        fontSize=18.sp,fontWeight=FontWeight.Bold,color=Ink)
                }
                Skill.WRITING -> {
                    Text(item.text,fontSize=17.sp,lineHeight=25.sp,color=Ink)
                    Text(if(LocalLanguage.current=="id") item.cueId else item.question,
                        color=Muted,fontSize=13.sp,lineHeight=20.sp)
                    OutlinedTextField(value=selected,onValueChange={if(!revealed)selected=it},
                        enabled=!revealed,modifier=Modifier.fillMaxWidth().heightIn(min=155.dp),
                        minLines=4,label={Text(loc("Tulisanmu dalam bahasa Inggris","Write in English"))},
                        shape=RoundedCornerShape(16.dp))
                    if(revealed) {
                        Surface(color=Color(0xFFE7F8F1),shape=RoundedCornerShape(17.dp)) {
                            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                                Text(loc("Contoh referensi (bukan satu-satunya jawaban)",
                                    "Reference example (not the only correct answer)"),
                                    color=Color(0xFF159B79),fontWeight=FontWeight.Bold)
                                Text(item.answer,color=Ink,lineHeight=24.sp)
                                val matched = item.keywords.count { selected.lowercase(Locale.ROOT).contains(it) }
                                Text(loc("Petunjuk struktur terpenuhi: $matched/${item.keywords.size}. Periksa sendiri makna, tata bahasa, dan pilihan kata.",
                                    "Structure hints matched: $matched/${item.keywords.size}. Review your meaning, grammar, and word choice yourself."),
                                    color=Muted,fontSize=12.sp,lineHeight=19.sp)
                                Text(loc("Pemeriksaan otomatis ini hanya kata kunci, bukan penilaian tulisan oleh AI.",
                                    "This is keyword guidance, not AI grading of your writing."),fontSize=11.sp,color=Muted)
                            }
                        }
                    }
                }
                Skill.SPEAKING -> {
                    Surface(color=VioletPale,shape=RoundedCornerShape(19.dp)) {
                        Column(Modifier.fillMaxWidth().padding(19.dp),verticalArrangement=Arrangement.spacedBy(13.dp)) {
                            Text(item.text,fontSize=20.sp,fontWeight=FontWeight.SemiBold,color=Ink,lineHeight=30.sp)
                            Text(if(LocalLanguage.current=="id") item.questionId else item.question,
                                fontSize=12.sp,color=Muted)
                            TextButton(onClick={say(item.text)}) {
                                Icon(Icons.Default.VolumeUp,null)
                                Spacer(Modifier.width(7.dp))
                                Text(loc("Dengar contoh","Hear example"))
                            }
                        }
                    }
                    Button(onClick={
                        try {
                            val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-US")
                                putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak in English")
                            }
                            launcher.launch(intent)
                        } catch (_: ActivityNotFoundException) {
                            error="No speech recognition service found."
                        } catch (_: Exception) {
                            error="Speech recognition is unavailable on this device."
                        }
                    },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Mic,null)
                        Spacer(Modifier.width(8.dp))
                        Text(loc("Mulai berbicara", "Start speaking"))
                    }
                    if(error.isNotBlank()) Text(error,color=Color(0xFFD4505D),fontSize=12.sp)
                    if(transcript.isNotBlank()) {
                        Surface(color=Color.White,shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,Border)) {
                            Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                Text(loc("Hasil yang didengar perangkat", "Device transcription"),
                                    fontWeight=FontWeight.Bold,color=Ink)
                                Text(transcript,color=Ink,lineHeight=25.sp)
                                Text(loc("Kata yang cocok dengan contoh: ${tokenMatch(item.text,transcript)}%. Ini bukan skor aksen atau pelafalan.",
                                    "Words matched to example: ${tokenMatch(item.text,transcript)}%. This is not an accent or pronunciation score."),
                                    fontSize=12.sp,color=Muted,lineHeight=20.sp)
                            }
                        }
                    }
                    Text(loc("Fitur ini menggunakan pengenalan suara di perangkat. Ketersediaan dan kebutuhan internet bergantung pada layanan suara Android.",
                        "Recognition uses the Android speech service. Availability and internet requirements depend on the installed service."),
                        color=Muted,fontSize=12.sp,lineHeight=19.sp)
                }
            }
            if(skill==Skill.READING || skill==Skill.LISTENING) {
                item.options.forEach { option ->
                    val active=selected==option
                    val correct=revealed && option==item.answer
                    Surface(modifier=Modifier.fillMaxWidth().clickable(enabled=!revealed){selected=option},
                        color=if(correct) Color(0xFFE7F8F1) else if(active) VioletPale else Color.White,
                        border=BorderStroke(1.dp,if(correct) Color(0xFF159B79) else if(active) Violet else Border),
                        shape=RoundedCornerShape(16.dp)) {
                        Text(option,modifier=Modifier.padding(16.dp),color=Ink)
                    }
                }
                if(revealed) {
                    Surface(color=if(selected==item.answer) Color(0xFFE7F8F1) else Color(0xFFFFEEF0),
                        shape=RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                            Text(if(selected==item.answer) loc("Benar!","Correct!") else loc("Belum tepat","Not quite"),
                                fontWeight=FontWeight.Bold,color=Ink)
                            Text("${loc("Jawaban","Answer")}: ${item.answer}",color=Ink)
                            Text(if(LocalLanguage.current=="id") item.explanationId else item.explanation,
                                color=Muted,lineHeight=21.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(15.dp))
        }
        Surface(color=Color.White,shadowElevation=4.dp) {
            Column(Modifier.padding(16.dp)) {
                val quiz = skill == Skill.READING || skill == Skill.LISTENING
                val canProceed = when(skill) {
                    Skill.READING,Skill.LISTENING -> revealed
                    Skill.WRITING -> revealed
                    Skill.SPEAKING -> true // manual completion remains possible if recognition is unavailable
                }
                if(!canProceed) {
                    PrimaryButton(if(quiz) loc("Periksa jawaban","Check answer") else loc("Lihat contoh tulisan","Review writing"),
                        Icons.Default.CheckCircle, { revealed=true },enabled=selected.trim().isNotEmpty())
                } else {
                    PrimaryButton(if(index==tasks.lastIndex) loc("Selesai","Finish") else loc("Kegiatan berikutnya","Next activity"),
                        Icons.Default.ArrowForward, ::advance)
                }
            }
        }
    }
}
