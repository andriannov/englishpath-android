package com.englishpath.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale

data class CourseLevel(val id: String, val name: String, val subtitle: String, val shade: String, val subtitleEn: String)
data class CourseExample(val en: String, val translation: String)
data class Mistake(val wrong: String, val right: String, val explanation: String, val explanationEn: String)
data class Exercise(
    val type: String,
    val prompt: String,
    val options: List<String>,
    val answer: String,
    val accepted: List<String>,
    val explanation: String,
    val promptEn: String = prompt, val explanationEn: String = explanation
) {
    fun isCorrect(response: String): Boolean {
        fun normalized(s: String) = s.trim().lowercase(Locale.ROOT)
            .replace(Regex("[.!?]+$"), "").replace(Regex("\\s+"), " ")
        return (if (type == "input") accepted else listOf(answer))
            .any { normalized(it) == normalized(response) }
    }
}
data class Lesson(
    val id: String,
    val level: String,
    val title: String,
    val category: String,
    val minutes: Int,
    val overview: String,
    val formula: String,
    val examples: List<CourseExample>,
    val mistake: Mistake,
    val questions: List<Exercise>,
    val overviewEn: String, val categoryEn: String
)
data class Course(val levels: List<CourseLevel>, val lessons: List<Lesson>)

object CourseRepository {
    private fun JSONArray.strings() = (0 until length()).map { getString(it) }
    fun load(context: Context): Course {
        val raw = context.assets.open("curriculum.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        val levels = root.getJSONArray("levels").let { array ->
            (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                CourseLevel(j.getString("id"), j.getString("name"), j.getString("subtitle"), j.getString("shade"), j.optString("subtitle_en",j.getString("subtitle")))
            }
        }
        val lessons = root.getJSONArray("lessons").let { array ->
            (0 until array.length()).map { i ->
                val j = array.getJSONObject(i)
                val exampleArray = j.getJSONArray("examples")
                val examples = (0 until exampleArray.length()).map { k ->
                    val e = exampleArray.getJSONObject(k)
                    CourseExample(e.getString("en"), e.getString("id"))
                }
                val m = j.getJSONObject("mistake")
                val qArray = j.getJSONArray("questions")
                val questions = (0 until qArray.length()).map { k ->
                    val q = qArray.getJSONObject(k)
                    Exercise(q.getString("type"), q.getString("prompt"),
                        q.getJSONArray("options").strings(), q.getString("answer"),
                        q.getJSONArray("accepted").strings(), q.getString("explanation"),
                        q.optString("prompt_en",q.getString("prompt")), q.optString("explanation_en",q.getString("explanation")))
                }
                Lesson(j.getString("id"), j.getString("level"), j.getString("title"),
                    j.getString("category"), j.getInt("minutes"), j.getString("overview"),
                    j.getString("formula"), examples,
                    Mistake(m.getString("wrong"), m.getString("right"), m.getString("explanation"),
                    m.optString("explanation_en",m.getString("explanation"))), questions,
                    j.optString("overview_en",j.getString("overview")),
                    j.optString("category_en",j.getString("category")))
            }
        }
        return Course(levels, lessons)
    }
}

data class SessionMistake(val prompt: String, val yourAnswer: String, val correctAnswer: String, val explanation: String)

class ProgressStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("englishpath_progress_v1", Context.MODE_PRIVATE)
    fun language(): String = prefs.getString("language", "id") ?: "id"
    fun setLanguage(lang: String) { prefs.edit().putString("language", lang).apply() }
    fun placementCompleted(): Boolean = prefs.getBoolean("placement_done", false)
    fun placementLevel(): String? = prefs.getString("placement_level", null)
    fun placementScore(): String? = prefs.getString("placement_score", null)
    fun skillSessions(skill: Skill): Int = prefs.getInt("skills_${skill.name}", 0)
    fun recordSkillActivity(skill: Skill) {
        prefs.edit().putInt("skills_${skill.name}", skillSessions(skill)+1).apply()
    }
    fun savePlacement(level: String, correct: Int, total: Int) {
        prefs.edit().putBoolean("placement_done", true).putString("placement_level", level)
            .putString("placement_score", "$correct/$total").apply()
    }
    fun completedIds(): Set<String> = prefs.getStringSet("completed", emptySet())?.toSet() ?: emptySet()
    fun bestScore(id: String): Int = prefs.getInt("best_$id", 0)
    fun xp(): Int = prefs.getInt("xp", 0)
    fun sessions(): Int = prefs.getInt("sessions", 0)
    fun streak(): Int {
        val last = prefs.getString("last_day", null) ?: return 0
        return try {
            val days = ChronoUnit.DAYS.between(LocalDate.parse(last), LocalDate.now())
            if (days <= 1) prefs.getInt("streak", 0) else 0
        } catch (_: Exception) { 0 }
    }
    fun recordSession(lessonId: String?, score: Int, total: Int) {
        val percentage = if (total == 0) 0 else score * 100 / total
        val today = LocalDate.now()
        val previous = prefs.getString("last_day", null)
        val newStreak = try {
            if (previous == today.toString()) prefs.getInt("streak", 0)
            else if (previous != null && LocalDate.parse(previous).plusDays(1) == today) prefs.getInt("streak", 0) + 1
            else 1
        } catch (_: Exception) { 1 }
        val editor = prefs.edit()
            .putInt("sessions", sessions() + 1)
            .putInt("xp", xp() + score * 10)
            .putString("last_day", today.toString())
            .putInt("streak", newStreak)
        if (lessonId != null) {
            editor.putInt("best_$lessonId", maxOf(bestScore(lessonId), percentage))
            if (percentage >= 75) {
                editor.putStringSet("completed", completedIds().toMutableSet().apply { add(lessonId) })
            }
        }
        editor.apply()
    }
    fun clear(course: Course) {
        val lang=language()
        prefs.edit().clear().putString("language",lang).apply()
    }
}
