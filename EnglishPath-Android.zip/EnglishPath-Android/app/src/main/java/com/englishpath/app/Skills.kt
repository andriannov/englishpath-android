package com.englishpath.app

enum class Skill(val label: String, val nameEn: String) {
    READING("Membaca","Reading"), LISTENING("Mendengarkan","Listening"),
    WRITING("Menulis","Writing"), SPEAKING("Berbicara","Speaking")
}

data class SkillTask(
    val level: String, val title: String, val titleId: String, val text: String,
    val question: String, val questionId: String, val options: List<String> = emptyList(),
    val answer: String = "", val explanation: String = "", val explanationId: String = "",
    val cueId: String = "", val keywords: List<String> = emptyList()
)

object SkillCatalog {
    private fun r(l:String,t:String,id:String,pass:String,q:String,qi:String,
        opts:String,ans:String,exp:String,ei:String) = SkillTask(l,t,id,pass,q,qi,opts.split('|'),ans,exp,ei)
    private fun w(l:String,t:String,id:String,task:String,example:String,exampleId:String,
        hint:String,keys:String) = SkillTask(l,t,id,task,example,exampleId,
        answer=example,cueId=hint,keywords=keys.split('|'))
    private fun s(l:String,t:String,id:String,pass:String) = SkillTask(l,t,id,pass,
        "Speak the sentence aloud.","Ucapkan kalimat ini dengan jelas.")

    val reading = listOf(
        r("A1","Morning Routine","Rutinitas pagi","Maya wakes up at six. She eats breakfast and walks to school with her sister.","How does Maya go to school?","Bagaimana Maya pergi ke sekolah?","By bus|On foot|By bicycle","On foot","She walks.","Maya berjalan kaki."),
        r("A1","The Grocery Shop","Toko bahan makanan","Tom buys three apples and one bottle of milk. The apples cost two dollars and the milk costs one dollar.","How much does he spend in total?","Berapa total uang yang dihabiskan?","$2|$3|$4","$3","Two plus one equals three.","Dua ditambah satu sama dengan tiga."),
        r("A2","Weekend Plans","Rencana akhir pekan","Nina will visit her grandmother on Saturday. On Sunday she will study for a test on Monday.","Why will she study on Sunday?","Mengapa dia belajar hari Minggu?","She has a test|She is bored|The school is closed","She has a test","The test is on Monday.","Tes berlangsung hari Senin."),
        r("A2","A Late Train","Kereta terlambat","The train normally leaves at 9:15. Yesterday it left at 9:45 due to heavy rain.","How late was the train?","Berapa lama kereta terlambat?","15 minutes|30 minutes|45 minutes","30 minutes","9:45 is thirty minutes after 9:15.","9.45 adalah 30 menit setelah 9.15."),
        r("B1","Remote Work","Kerja jarak jauh","Since joining her new company, Ana has worked remotely three days a week. She likes the flexibility but misses chats with coworkers.","What does Ana miss?","Apa yang dirindukan Ana?","Long commutes|Informal conversations|Early meetings","Informal conversations","She misses conversations with coworkers.","Dia merindukan percakapan dengan rekan kerja."),
        r("B1","A Community Garden","Kebun komunitas","Residents turned an empty lot into a vegetable garden. Although it began small, dozens of families now grow food there.","What happened over time?","Apa yang terjadi seiring waktu?","It expanded|It closed|It moved","It expanded","More families joined.","Lebih banyak keluarga bergabung."),
        r("B2","Urban Transport","Transportasi perkotaan","The city built protected cycle lanes to reduce car use. Surveys showed interest in cycling, but gaps between routes remained a serious barrier.","What remains a problem?","Apa yang masih menjadi masalah?","Expensive bikes|Disconnected routes|Bad weather","Disconnected routes","Gaps between routes are mentioned as a barrier.","Rute yang tidak tersambung masih menjadi hambatan."),
        r("B2","Study Research","Penelitian belajar","Researchers compared two groups over six months. Spaced revision improved recall, yet the authors warned that their sample was small.","Why interpret results cautiously?","Mengapa hasilnya harus ditafsirkan hati-hati?","The sample was small|There was no research|All tests failed","The sample was small","Small samples limit certainty.","Sampel kecil membatasi kepastian."),
        r("C1","Technology and Judgment","Teknologi dan penilaian","Automated recommendations increase efficiency; nevertheless, they may conceal assumptions embedded in the data. Human oversight remains indispensable.","What is the central claim?","Apa gagasan utamanya?","Technology is neutral|Human oversight matters|All automation must stop","Human oversight matters","The author warns against relying solely on automation.","Penulis memperingatkan agar kita tidak sepenuhnya mengandalkan otomasi."),
        r("C1","Scientific Uncertainty","Ketidakpastian ilmiah","Preliminary results appear promising. However, confounding variables have not been excluded, so a causal interpretation would be premature.","What is the author's attitude?","Bagaimana sikap penulis?","Total certainty|Cautious optimism|Complete rejection","Cautious optimism","Promising results are paired with uncertainty.","Hasil menjanjikan tetapi masih ada ketidakpastian.")
    )
    val listening = listOf(
        r("A1","Finding the Library","Mencari perpustakaan","The library is next to the bank. It opens at nine o'clock.","Where is the library?","Di mana perpustakaan?","Next to the bank|Behind the school|Across the park","Next to the bank","Listen for next to.","Dengarkan frasa next to."),
        r("A1","Food Preferences","Kesukaan makanan","I like rice and chicken, but I don't like fish.","What food does the speaker dislike?","Makanan apa yang tidak disukai?","Rice|Fish|Chicken","Fish","The speaker says don't like fish.","Pembicara mengatakan tidak suka ikan."),
        r("A2","Yesterday's Weather","Cuaca kemarin","It was sunny this morning, but it started raining after lunch.","When did it rain?","Kapan hujan turun?","Before breakfast|After lunch|At midnight","After lunch","The rain started after lunch.","Hujan dimulai setelah makan siang."),
        r("A2","Travel Plans","Rencana perjalanan","We are going to take the bus on Friday because the train is too expensive.","Why take the bus?","Mengapa memilih bus?","The train costs too much|It is faster|The train is broken","The train costs too much","The speaker mentions the train's price.","Pembicara menyebut harga kereta."),
        r("B1","A New Job","Pekerjaan baru","I've worked in customer service for three years, and I recently completed a training course.","How long has the speaker worked there?","Sudah berapa lama pembicara bekerja?","Three years|Three months|One year","Three years","For describes a duration.","For menunjukkan durasi."),
        r("B1","A Missed Meeting","Rapat terlewat","By the time I arrived, the meeting had already started. I joined as quietly as possible.","What happened first?","Apa yang terjadi lebih dahulu?","The meeting started|The meeting ended|Everyone left","The meeting started","Past perfect marks the earlier event.","Past perfect menunjukkan peristiwa terdahulu."),
        r("B2","Project Delay","Keterlambatan proyek","Had we received the materials earlier, we could have completed the work last week.","What caused the delay?","Apa penyebab keterlambatan?","Late materials|Missing staff|Bad instructions","Late materials","Materials did not arrive early enough.","Bahan tidak tiba cukup awal."),
        r("B2","A Polite Suggestion","Saran yang sopan","I appreciate the proposal. However, I would recommend reviewing the budget before setting a deadline.","What should happen first?","Apa yang harus dilakukan lebih dahulu?","Review the budget|Cancel the project|Recruit staff","Review the budget","The budget review is the prerequisite.","Peninjauan anggaran menjadi prasyarat."),
        r("C1","Academic Debate","Debat akademik","While the evidence may appear compelling, generalising beyond the population studied would be imprudent.","What is the warning?","Apa peringatannya?","Do not overgeneralise|Stop gathering data|Reject peer review","Do not overgeneralise","The sample may not represent other populations.","Sampel belum tentu mewakili populasi lain."),
        r("C1","Policy Trade-offs","Konsekuensi kebijakan","Not only might the reform lower costs, but it could also redistribute responsibilities in ways requiring closer scrutiny.","What needs scrutiny?","Apa yang perlu diperiksa lebih lanjut?","Changed responsibilities|Guaranteed losses|No possible savings","Changed responsibilities","The reform may change who is responsible.","Reformasi mungkin mengubah pembagian tanggung jawab.")
    )
    val writing = listOf(
        w("A1","Introduce Yourself","Perkenalkan diri","Write two sentences about your name and city.","My name is Dita. I live in Jakarta.","Nama saya Dita. Saya tinggal di Jakarta.","Gunakan My name is... dan I live in...","my name|live"),
        w("A1","Daily Routine","Rutinitas harian","Write one sentence about your morning routine.","I drink water every morning.","Saya minum air setiap pagi.","Gunakan Simple Present dan keterangan waktu.","i|every"),
        w("A2","Yesterday","Hari kemarin","Write two sentences about yesterday.","I visited my friend yesterday. We played chess.","Saya mengunjungi teman kemarin. Kami bermain catur.","Gunakan kata kerja lampau.","yesterday"),
        w("A2","Future Plan","Rencana mendatang","Write one sentence about next weekend.","I am going to visit my family next weekend.","Saya akan mengunjungi keluarga akhir pekan depan.","Gunakan be going to.","going to"),
        w("B1","A New Skill","Keterampilan baru","Describe a skill you have learned and why.","I have learned to cook because I want to be independent.","Saya telah belajar memasak karena ingin mandiri.","Coba Present Perfect + because.","have|because"),
        w("B1","Give Advice","Berikan saran","Give advice to someone learning English.","You should practise daily, and you could listen to podcasts.","Sebaiknya berlatih tiap hari dan mendengar podcast.","Gunakan modal verbs: should, can atau could.","should"),
        w("B2","Contrast Opinions","Bandingkan pendapat","Contrast online learning with classroom learning.","Online classes are flexible; however, classrooms encourage discussion.","Kelas daring fleksibel; namun, kelas tatap muka mendorong diskusi.","Gunakan however atau although.","however"),
        w("B2","Regret","Penyesalan","Write something you wish you had done differently.","I wish I had prepared earlier because I missed the deadline.","Saya berharap dahulu mempersiapkan diri lebih awal.","Gunakan wish + had + V3.","wish|had"),
        w("C1","Hedging","Klaim berhati-hati","Write a cautious claim about technology.","The findings may suggest that automation improves efficiency.","Temuan mungkin menunjukkan bahwa otomasi meningkatkan efisiensi.","Gunakan may, might atau appears to.","may"),
        w("C1","Formal Recommendation","Rekomendasi formal","Write a formal recommendation for a workplace policy.","It is essential that the committee review the policy.","Penting agar komite meninjau kebijakan tersebut.","Gunakan pola It is essential that....","that")
    )
    val speaking = listOf(
        s("A1","Introduce Yourself","Perkenalan","My name is Alex and I live in Indonesia."),
        s("A1","Ask a Question","Bertanya","Where do you live?"),
        s("A2","Future Plan","Rencana mendatang","I am going to study English tonight."),
        s("A2","Past Event","Kejadian masa lalu","Yesterday I went to the market with my sister."),
        s("B1","Recent Progress","Perkembangan terbaru","I have been practising my English for several weeks."),
        s("B1","Give Advice","Berikan saran","If you want to improve, you should practise every day."),
        s("B2","Hypothetical Situation","Pengandaian","If I had known about the meeting, I would have attended."),
        s("B2","A Nuanced Opinion","Pendapat bernuansa","Although the idea has merit, it might be difficult to implement."),
        s("C1","Formal Emphasis","Penekanan formal","Rarely have we encountered such a complex challenge."),
        s("C1","Careful Conclusion","Kesimpulan berhati-hati","The evidence appears to suggest a relationship, albeit a tentative one.")
    )
    fun tasks(skill:Skill):List<SkillTask> = when(skill) {
        Skill.READING->reading; Skill.LISTENING->listening
        Skill.WRITING->writing; Skill.SPEAKING->speaking
    }
}
