package com.englishpath.app

/** 20-item formative screening: four randomly drawn questions at each CEFR band. */
object Placement {
    val levels = listOf("A1", "A2", "B1", "B2", "C1")
    fun questions(course: Course): List<Pair<Lesson, Exercise>> = levels.flatMap { level ->
        course.lessons.filter { it.level == level }
            .flatMap { lesson -> lesson.questions.map { lesson to it } }
            .shuffled().take(4)
    }
    fun recommend(items: List<Pair<Lesson, Exercise>>, answers: List<Boolean>): String {
        val scores=mutableMapOf<String,Int>()
        items.forEachIndexed { i, (lesson,_) ->
            if(answers.getOrNull(i)==true) scores[lesson.level]=(scores[lesson.level]?:0)+1
        }
        for (level in levels.dropLast(1)) if((scores[level]?:0)<3) return level
        return "C1"
    }
}
