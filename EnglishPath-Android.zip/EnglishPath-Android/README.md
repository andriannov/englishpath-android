# EnglishPath — Android English Learning App

**Versi 1.1 (prototipe Android native, Kotlin + Jetpack Compose).** Dibuat agar pengguna yang hanya memiliki smartphone bisa membangun APK dengan layanan kompilasi cloud.

## Isi aplikasi

- **Bahasa tampilan:** Bahasa Indonesia / English; pilih sejak layar awal atau dari menu Progres.
- **Placement Test:** 20 soal dari tingkat A1–C1 (empat soal per tingkat), dengan rekomendasi level berdasarkan jawaban. Tes ini hanya *screening* awal grammar/kalimat pendek, **bukan sertifikasi CEFR ataupun uji penuh keempat keterampilan**.
- **45 materi grammar (A1–C1)** mencakup to be, nouns, articles, verbs, auxiliaries, adverbs, tenses, modals, conditionals, passive voice, relative clauses, inversion, academic writing structures, dan lainnya.
- **180 soal grammar:** pilihan ganda, isian, soal koreksi kalimat, umpan balik benar/salah, pembahasan, dan nilai.
- **Reading:** 10 bacaan pendek (dua per level), dengan soal pemahaman dan penjelasan.
- **Listening:** 10 materi audio dari Android Text-to-Speech, pemahaman kalimat, dan transkrip setelah jawaban dicek.
- **Writing:** 10 tugas menulis dan contoh referensi. Pemeriksaan kata kunci adalah petunjuk, **bukan koreksi esai secara menyeluruh**.
- **Speaking:** 10 kalimat tiruan, tombol dengar pengucapan, dan pengenalan suara melalui layanan Android. Kecocokan transkrip **bukan tes pengucapan atau aksen**.
- Progress materi, XP, streak, pilihan bahasa, dan level rekomendasi disimpan lokal dengan Android SharedPreferences.
- Tanpa akun, iklan, atau backend server. Materi teks bekerja offline; fungsi suara bergantung pada mesin suara Android yang terpasang, dan mungkin membutuhkan internet.

## Mendapatkan APK dari smartphone Android saja

Cara yang meminimalkan pekerjaan di HP: **unggah satu ZIP sumber ke GitHub dan buat satu workflow**. Tidak perlu Android Studio, JDK, laptop, ataupun komputer pada HP.

1. Download **`EnglishPath-Android.zip`** dan **`Build-EnglishPath-from-ZIP.yml`** dari percakapan.
2. Buka Chrome di HP dan masuk ke [github.com/new](https://github.com/new). Daftar/masuk, kemudian buat repository baru, misalnya `englishpath-android`. Centang *Add a README*. Aktifkan **Situs desktop** di Chrome bila menu tidak terlihat.
3. Di repository pilih **Add file → Upload files**. Upload **`EnglishPath-Android.zip`** sebagai satu file tanpa diekstrak. Klik **Commit changes**.
4. Pilih **Add file → Create new file**. Di kolom nama isi **`.github/workflows/build.yml`**. Buka file `Build-EnglishPath-from-ZIP.yml` di HP, salin seluruh isinya, tempel di editor GitHub, lalu **Commit changes**.
5. Buka tab **Actions → Build EnglishPath APK from ZIP**. Jika belum otomatis mulai, ketuk **Run workflow**.
6. Setelah workflow sukses (hijau), buka run tersebut dan bagian **Artifacts**. Download **EnglishPath-APK** (ZIP), ekstrak, lalu instal `app-debug.apk`.
7. Jika Android meminta izin pemasangan dari sumber eksternal, izinkan hanya untuk sumber yang kamu percayai. Ini **APK debug/prototipe**, belum rilis produksi dan belum diterbitkan di Play Store.

GitHub Actions menjalankan Android SDK / Gradle di server, bukan di smartphone. Akun gratis umumnya dapat memakai workflow untuk repo publik dalam batas layanan GitHub yang berlaku. Untuk penggunaan, build, dan distribusi publik, tinjau ketentuan GitHub.

## Detail teknis

- Android minimal 8.0 (API 26). Compile/target SDK 35.
- Java 17, Gradle 8.13, Android Gradle Plugin 8.13.2, Kotlin 2.2.21.
- Compose BOM 2026.09.00, tanpa plugin pihak ketiga untuk penyimpanan/fitur suara.
- Source Android ada pada `app/src/main/java/com/englishpath/app/`.
- Konten materi offline berada di `app/src/main/assets/curriculum.json`.
- `generate_content.py` menghasilkan ulang JSON Indonesia; setelah mengubah materi/menjalankannya, jalankan `augment_english.py` untuk memperbarui kolom bahasa Inggris.
- Workflow `EnglishPath-Android/.github/workflows/build-apk.yml` juga tersedia untuk repository yang diunggah sebagai folder lengkap.

## Keterbatasan prototipe

- APK **belum dikompilasi atau diuji pada perangkat nyata di lingkungan ini**. Jika cloud build menemukan error, lihat log Actions dan perbaiki source dari log tersebut.
- Penjelasan Inggris pada kuis mencakup rumus/pola dan jawaban referensi; penjelasan Indonesia lebih spesifik terhadap kesalahan pada soal. Peningkatan editorial bilingual masih diperlukan.
- Tes penempatan hanya mengestimasi kompetensi grammar/kalimat, bukan kemampuan berbicara/menyimak/menulis sebenarnya. Untuk penilaian profesional perlu instrumen tervalidasi, rubrik, dan sampling yang lebih luas.
- Writing memakai checklist kata kunci, bukan AI grading. Speaking memakai speech-to-text Android, bukan penilaian fonetik.
- Tidak ada login, sinkronisasi cloud, push notifications, atau sistem unduhan materi.
- Android menghapus progres jika data aplikasi dihapus. Buat backup sebelum menghapus aplikasi.
