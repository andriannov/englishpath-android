"""Creates the fully-offline course bundled in assets. Python only needed to edit content."""
import json, os
lessons=[]

def c(prompt, opts, idx, why):
    return dict(type='choice',prompt=prompt,options=opts.split('|'),answer=opts.split('|')[idx],accepted=[],explanation=why)
def f(prompt, answer, why):
    return dict(type='input',prompt=prompt,options=[],answer=answer.split('|')[0],accepted=answer.split('|'),explanation=why)
def add(level,title,category,description,formula,example,translation,wrong,right,why,questions):
    index = len(lessons)+1
    assert len(questions)==3 and questions[0]['type']=='choice'
    corrected = c('Pilih kalimat yang paling tepat sesuai materi.',
        (right+'|'+wrong if index%2==0 else wrong+'|'+right),
        (0 if index%2==0 else 1),why)
    lessons.append(dict(id=f'L{index:02}',level=level,title=title,category=category,
        minutes=5+index%4,overview=description,formula=formula,
        examples=[dict(en=example,id=translation)],
        mistake=dict(wrong=wrong,right=right,explanation=why),
        questions=questions+[corrected]))

# A1 — foundation
add('A1','Subject Pronouns & To Be','Dasar kalimat',
'Gunakan I, you, he, she, it, we, they sebagai subjek. Bentuk be pada masa kini berubah menjadi am, is, atau are. To be menghubungkan subjek dengan sifat, identitas, atau tempat.',
'I am · He/She/It is · You/We/They are',
'She is a teacher.','Dia adalah seorang guru.',
'She are a teacher.','She is a teacher.','She memakai is, bukan are.',[
 c('My parents ___ at home.','am|is|are',2,'Parents jamak, jadi memakai are.'),
 f('Lengkapi: I ___ ready.','am','Subjek I selalu berpasangan dengan am.'),
 c('___ he your brother?','Is|Are|Do',0,'Pertanyaan to be memindahkan is ke depan subjek.')])
add('A1','Nouns, Articles & Plurals','Kata benda',
'Noun menamai orang, benda, tempat, atau ide. Kata benda tunggal yang dapat dihitung umumnya memakai a/an atau penentu lain. Gunakan an sebelum bunyi vokal; plural biasanya memakai -s/-es.',
'a book · an apple · two books · a university',
'I have an umbrella.','Saya mempunyai sebuah payung.',
'I have a umbrella.','I have an umbrella.','Umbrella diawali bunyi vokal, sehingga memakai an.',[
 c('Choose the correct phrase.','an university|a university|a apples',1,'University diawali bunyi /juː/, jadi a university.'),
 f('One box, two ___.','boxes','Box membentuk jamak dengan akhiran -es.'),
 c('Which is a plural noun?','child|children|a child',1,'Children adalah bentuk jamak tidak beraturan dari child.')])
add('A1','Possessives & Demonstratives','Penunjuk dan kepemilikan',
'My, your, his, her, its, our, their ditempatkan sebelum noun. This/these menunjuk yang dekat; that/those menunjuk yang jauh. Bedakan its (miliknya) dengan it’s (it is).',
'my bag · this book · those shoes · her phone',
'Those are my shoes.','Itu adalah sepatu-sepatuku.',
'This are my shoes.','These are my shoes.','Shoes jamak, maka penunjuk dekat adalah these.',[
 c('___ book is mine. (dekat, tunggal)','This|These|Those',0,'This menunjuk satu benda yang dekat.'),
 f('Lengkapi: She loves ___ mother.','her','Her adalah possessive determiner untuk she.'),
 c('Which refers to far plural objects?','that|those|this',1,'Those berarti benda jamak yang jauh.')])
add('A1','Simple Present: Statements','Rutinitas dan fakta',
'Simple Present digunakan untuk kebiasaan, jadwal, dan fakta umum. Verb subjek he/she/it mendapat -s/-es; I/you/we/they memakai bentuk dasar.',
'I/You/We/They work · He/She/It works',
'My sister works every day.','Saudara perempuanku bekerja setiap hari.',
'My sister work every day.','My sister works every day.','Subjek my sister = she, jadi works.',[
 c('He ___ English every night.','study|studies|studying',1,'Study berubah menjadi studies untuk he.'),
 f('Lengkapi: They ___ coffee in the morning.','drink','They memakai verb dasar drink.'),
 c('A fact is best expressed with...','Simple Present|Past Continuous|Future Perfect',0,'Fakta umum umumnya menggunakan Simple Present.')])
add('A1','Do/Does: Negatives & Questions','Auxiliary verbs',
'Do/does merupakan auxiliary untuk menyangkal atau menanyakan kegiatan di Simple Present. Setelah does/doesn’t, verb kembali ke bentuk dasar.',
'Do you work? · Does she work? · He does not work.',
'Does she like tea?','Apakah dia menyukai teh?',
'Does she likes tea?','Does she like tea?','Setelah does, gunakan like tanpa -s.',[
 c('He ___ not eat meat.','do|does|is',1,'He memakai does not + base verb.'),
 f('Lengkapi: ___ they live here?','Do','They memakai auxiliary do.'),
 c('Which is correct?','She doesn’t like it.|She doesn’t likes it.|She don’t like it.',0,'Doesn’t diikuti base verb like.')])
add('A1','Present Continuous','Kegiatan berlangsung',
'Present Continuous menyatakan aktivitas yang sedang berlangsung atau situasi sementara. Gunakan am/is/are + verb-ing. Beberapa state verbs seperti know atau believe biasanya tidak digunakan dalam continuous.',
'am/is/are + verb-ing',
'They are studying now.','Mereka sedang belajar sekarang.',
'They is studying now.','They are studying now.','They berpasangan dengan are.',[
 c('Listen! The baby ___ .','cries|is crying|cry',1,'Aktivitas yang sedang terjadi menggunakan is crying.'),
 f('Lengkapi: I am ___ a book. (read)','reading','Read + -ing menjadi reading.'),
 c('Which signal often indicates now?','at the moment|every Monday|last year',0,'At the moment mengacu pada aktivitas yang berlangsung sekarang.')])
add('A1','There Is / There Are & Prepositions','Keberadaan dan tempat',
'There is untuk satu benda atau uncountable; there are untuk jamak. Kata depan lokasi umum: in, on, under, next to, between, behind, in front of.',
'There is + singular · There are + plural',
'There are three books on the table.','Ada tiga buku di atas meja.',
'There is three books on the table.','There are three books on the table.','Three books jamak sehingga menggunakan there are.',[
 c('There ___ some water in the glass.','is|are|am',0,'Water tidak dapat dihitung, maka is.'),
 f('Lengkapi: The cat is ___ the box. (di dalam)','in','In berarti di dalam.'),
 c('The lamp is ___ the table. (di atas)','on|under|between',0,'On menunjukkan posisi di atas permukaan.')])
add('A1','Adjectives & Frequency Adverbs','Sifat dan keterangan',
'Adjective menjelaskan noun (a happy child). Adverb of frequency menjelaskan seberapa sering sesuatu terjadi: always, usually, often, sometimes, never. Umumnya diletakkan sebelum main verb tetapi setelah be.',
'He often walks · She is always kind',
'She is usually early.','Dia biasanya datang lebih awal.',
'She usually early.','She is usually early.','Frequency adverb biasanya setelah be: is usually.',[
 c('He ___ goes to bed at 10.','usually|beautiful|quick',0,'Usually adalah adverb frekuensi.'),
 f('Lengkapi: She is ___ late. (tidak pernah)','never','Never berarti tidak pernah.'),
 c('Choose the adjective.','happily|happy|often',1,'Happy adalah adjective, happily adverb.')])
add('A1','Wh-Questions & Imperatives','Pertanyaan dan instruksi',
'Question words: who (siapa), what (apa), where (di mana), when (kapan), why (mengapa), how (bagaimana). Imperative menggunakan bentuk dasar verb untuk perintah atau instruksi.',
'Where do you live? · Please open the door.',
'Where does he live?','Di mana dia tinggal?',
'Where does he lives?','Where does he live?','Setelah does gunakan live, bukan lives.',[
 c('___ do you work? — At a hospital.','When|Where|Why',1,'At a hospital menjelaskan tempat: where.'),
 f('Lengkapi: Please ___ the window. (buka)','open','Imperative menggunakan base verb open.'),
 c('Which asks for a reason?','Why|Who|Where',0,'Why berarti mengapa.')])

# A2 — core structures
add('A2','Simple Past: Regular & Irregular Verbs','Masa lalu',
'Simple Past dipakai untuk peristiwa selesai di masa lalu. Regular verbs memakai -ed; irregular verbs memiliki bentuk V2 khusus. Negatif dan pertanyaan memakai did + bentuk dasar.',
'Subject + V2 · did not + V1 · Did + subject + V1?',
'I went to the market yesterday.','Saya pergi ke pasar kemarin.',
'I goed to the market yesterday.','I went to the market yesterday.','Bentuk lampau go adalah went, bukan goed.',[
 c('She ___ a movie last night.','watch|watched|watches',1,'Last night adalah past; watched bentuk V2.'),
 f('Lengkapi: I ___ a book yesterday. (buy)','bought','Past form dari buy adalah bought.'),
 c('Which is correct?','Did you went?|Did you go?|Do you went?',1,'Did diikuti base verb go.')])
add('A2','Was / Were','To be masa lalu',
'Was/were adalah bentuk lampau dari be. I/he/she/it memakai was; you/we/they memakai were. Digunakan untuk keadaan dan lokasi di masa lampau, tanpa auxiliary did.',
'I was · She was · You/We/They were',
'We were tired after work.','Kami lelah setelah bekerja.',
'We was tired after work.','We were tired after work.','We menggunakan were.',[
 c('___ she at home yesterday?','Did|Was|Were',1,'Pertanyaan keadaan lampau: Was she...?'),
 f('Lengkapi: They ___ very happy.','were','They menggunakan were.'),
 c('Which statement is correct?','I was hungry.|I were hungry.|I did hungry.',0,'I menggunakan was untuk adjective hungry.')])
add('A2','Past Continuous','Aktivitas sedang berlangsung di masa lalu',
'Past Continuous mendeskripsikan aktivitas yang sedang terjadi pada waktu tertentu di masa lalu. Sering dipasangkan dengan Simple Past untuk interupsi: was/were + verb-ing.',
'was/were + verb-ing · while + continuous · when + past',
'I was cooking when you called.','Saya sedang memasak ketika kamu menelepon.',
'I were cooking when you called.','I was cooking when you called.','I menggunakan was, bukan were.',[
 c('While she ___, the phone rang.','slept|was sleeping|sleep',1,'Aksi yang sedang berlangsung: was sleeping.'),
 f('Lengkapi: They were ___ football at 4 PM. (play)','playing','Were + playing (verb-ing).'),
 c('Which word often introduces an interruption?','when|every day|usually',0,'When sering memperkenalkan kejadian singkat yang menginterupsi.')])
add('A2','Will vs Be Going To','Rencana dan prediksi',
'Will lazim digunakan untuk keputusan spontan, janji, dan prediksi umum. Be going to digunakan untuk rencana yang telah dipikirkan dan prediksi berdasarkan bukti yang terlihat.',
'will + V1 · am/is/are going to + V1',
'Look at those clouds! It is going to rain.','Lihat awan itu! Sepertinya akan hujan.',
'She going to study tonight.','She is going to study tonight.','Going to memerlukan am/is/are.',[
 c('I forgot my pen. I ___ borrow one.','will|was|have',0,'Keputusan spontan dapat dinyatakan dengan will.'),
 f('Lengkapi: We are going to ___ tomorrow. (travel)','travel','Going to diikuti base verb travel.'),
 c('A plan decided yesterday:','I am going to study.|I did studying.|I will studied.',0,'Be going to cocok untuk rencana yang sudah dibuat.')])
add('A2','Countable, Uncountable & Quantifiers','Jumlah',
'Countable nouns dapat dihitung (books); uncountable nouns tidak dihitung satu per satu (water). Many/few untuk countable; much/little untuk uncountable; some/any digunakan sesuai struktur dan konteks.',
'many books · much water · a few apples · a little milk',
'How much water do you need?','Berapa banyak air yang kamu butuhkan?',
'How many water do you need?','How much water do you need?','Water uncountable sehingga memakai much.',[
 c('We have ___ chairs.','much|many|a little',1,'Chairs countable plural, jadi many.'),
 f('Lengkapi: Is there ___ sugar? (sedikit, tidak spesifik dalam pertanyaan)','any','Any lazim dalam pertanyaan netral.'),
 c('Which is uncountable?','advice|chairs|apples',0,'Advice adalah uncountable noun.')])
add('A2','Comparatives & Superlatives','Perbandingan',
'Comparative membandingkan dua benda (taller, more interesting). Superlative menyatakan tingkat tertinggi dalam suatu kelompok (the tallest, the most interesting). Beberapa irregular: good–better–best.',
'adjective-er / more + adjective · the -est / the most',
'This book is better than that one.','Buku ini lebih bagus daripada yang itu.',
'This book is more better than that one.','This book is better than that one.','Better sudah bentuk comparative; jangan tambah more.',[
 c('This is ___ building in town.','tall|taller|the tallest',2,'In town membandingkan satu dengan seluruh kelompok.'),
 f('Lengkapi: My bag is ___ than yours. (heavy)','heavier','Heavy berubah menjadi heavier.'),
 c('Comparative of good is...','gooder|better|best',1,'Bentuk tidak beraturan: good–better–best.')])
add('A2','Modal Verbs: Can, Should, Must','Kemampuan, saran, kewajiban',
'Modal auxiliaries can/could/should/must menunjukkan kemampuan, kemungkinan, saran, kewajiban. Setelah modal gunakan verb dasar tanpa to, kecuali ungkapan have to.',
'can/should/must + V1 · have to + V1',
'You should drink more water.','Sebaiknya kamu minum lebih banyak air.',
'You should to drink more water.','You should drink more water.','Setelah should, gunakan base verb tanpa to.',[
 c('You ___ wear a seat belt. It’s required.','must|might|could',0,'Must menyatakan kewajiban kuat.'),
 f('Lengkapi: She can ___ very well. (swim)','swim','Can + base verb swim.'),
 c('Which offers advice?','You should rest.|You can ran.|You must to sleep.',0,'Should + V1 menandakan saran.')])
add('A2','Present Perfect: Introduction','Pengalaman dan hasil',
'Present Perfect menghubungkan masa lalu dengan keadaan sekarang. Gunakan have/has + past participle (V3). Cocok untuk pengalaman, hasil yang masih relevan, just/already/yet, serta for/since.',
'have/has + V3 · have been · has eaten',
'She has finished her homework.','Dia sudah menyelesaikan PR-nya.',
'She have finished her homework.','She has finished her homework.','She memakai has, bukan have.',[
 c('I have never ___ sushi.','eat|ate|eaten',2,'Have diikuti past participle eaten.'),
 f('Lengkapi: He has ___ his keys. (lose)','lost','V3 dari lose adalah lost.'),
 c('Which refers to unfinished time?','today|yesterday in 2010|last Monday',0,'Today dapat mencakup periode yang belum berakhir.')])
add('A2','Gerunds & Infinitives','Bentuk kata kerja',
'Gerund berbentuk verb-ing dan dapat berfungsi sebagai noun. Infinitive adalah to + base verb. Pola bergantung pada verb: enjoy + -ing, want + to-infinitive. Sebagian verb menerima keduanya dengan perbedaan makna.',
'enjoy + V-ing · want + to V1 · avoid + V-ing',
'I enjoy reading novels.','Saya menikmati membaca novel.',
'I enjoy to read novels.','I enjoy reading novels.','Enjoy diikuti gerund (-ing).',[
 c('She decided ___ abroad.','studying|to study|study',1,'Decide biasanya diikuti to-infinitive.'),
 f('Lengkapi: He avoids ___ late. (arrive)','arriving','Avoid diikuti verb-ing.'),
 c('Which uses the correct pattern?','I want to learn.|I want learning.|I enjoy to swim.',0,'Want + to-infinitive adalah pola baku.')])

# B1 — intermediate
add('B1','Present Perfect vs Simple Past','Penanda waktu',
'Pilih Simple Past untuk waktu lampau yang sudah selesai dan spesifik; pilih Present Perfect untuk pengalaman/hasil tanpa waktu lampau spesifik atau periode yang berlanjut.',
'I saw him yesterday · I have seen him before',
'I visited Bali last year.','Saya mengunjungi Bali tahun lalu.',
'I have visited Bali last year.','I visited Bali last year.','Last year adalah waktu lampau selesai; gunakan Simple Past.',[
 c('Choose Present Perfect for a current result: I ___ my keys.','lost|have lost|had lost',1,'Hasil kehilangan kunci masih relevan sekarang.'),
 f('Lengkapi: She ___ here in 2020. (work)','worked','In 2020 menunjukkan waktu selesai: Simple Past.'),
 c('Which adverb suits Present Perfect experience?','ever|yesterday|in 1999',0,'Ever sering dipakai untuk pengalaman tanpa waktu spesifik.')])
add('B1','Present Perfect Continuous','Durasi aktivitas',
'Present Perfect Continuous menekankan aktivitas yang dimulai di masa lalu dan berlanjut atau baru saja selesai dengan dampak terlihat. Gunakan have/has been + verb-ing.',
'have/has been + V-ing · for + duration · since + point',
'I have been studying for two hours.','Saya sudah belajar selama dua jam.',
'I have studying for two hours.','I have been studying for two hours.','Present Perfect Continuous perlu been di antara have dan -ing.',[
 c('She has been ___ since noon.','work|working|worked',1,'Has been + verb-ing = working.'),
 f('Lengkapi: I have been waiting ___ 8 AM.','since','Since diikuti titik awal waktu.'),
 c('For five years refers to...','duration|starting point|future plan',0,'For menunjukkan durasi.')])
add('B1','Past Perfect','Urutan kejadian di masa lalu',
'Past Perfect menyatakan peristiwa yang lebih dulu selesai sebelum peristiwa lampau lain. Tidak semua dua kejadian lampau wajib Past Perfect, tetapi bentuk ini memperjelas urutan.',
'had + V3 · by the time + Simple Past',
'The train had left before I arrived.','Kereta sudah berangkat sebelum saya tiba.',
'The train had leave before I arrived.','The train had left before I arrived.','Setelah had harus past participle: left.',[
 c('When I arrived, she ___ already left.','has|had|have',1,'Peristiwa selesai sebelum kedatangan: had left.'),
 f('Lengkapi: He had ___ dinner before 7. (eat)','eaten','V3 dari eat adalah eaten.'),
 c('Which happened first? "She had slept before he came."','she slept|he came|same time',0,'Past Perfect menunjukkan tidur terjadi lebih dahulu.')])
add('B1','Zero & First Conditionals','Kondisi nyata',
'Zero conditional untuk fakta/kebiasaan umum: if + present, present. First conditional untuk kemungkinan masa depan yang realistis: if + present, will + base verb.',
'If + present, present · If + present, will + V1',
'If it rains, we will stay home.','Jika hujan, kami akan tinggal di rumah.',
'If it will rain, we will stay home.','If it rains, we will stay home.','Dalam if-clause First Conditional, gunakan Present Simple, bukan will.',[
 c('If you heat ice, it ___.','melts|will melted|melting',0,'Zero Conditional menyatakan fakta umum.'),
 f('Lengkapi: If I see him, I ___ tell him.','will','Main clause First Conditional menggunakan will.'),
 c('A realistic future possibility uses...','First Conditional|Third Conditional|Past Perfect',0,'First Conditional cocok untuk kemungkinan nyata masa depan.')])
add('B1','Second Conditional','Situasi hipotetis',
'Second Conditional membicarakan situasi tidak nyata, tidak mungkin, atau imajinatif sekarang/masa depan: if + past, would + V1. Were dapat digunakan untuk semua subjek dalam gaya formal/hipotetis.',
'If + Simple Past, would + V1',
'If I had more time, I would travel.','Seandainya saya punya lebih banyak waktu, saya akan bepergian.',
'If I have more time, I would travel.','If I had more time, I would travel.','Second Conditional menggunakan past form dalam if-clause.',[
 c('If I ___ rich, I would buy a house.','am|were|will be',1,'If I were lazim untuk hipotesis.'),
 f('Lengkapi: If she knew, she ___ help.','would','Would + base verb menyatakan akibat hipotesis.'),
 c('Second Conditional describes...','imaginary present/future|routine facts|completed history',0,'Ini pola untuk situasi tidak nyata sekarang/masa depan.')])
add('B1','Defining Relative Clauses','Klausa relatif',
'Defining relative clause menjelaskan noun secara penting. Who untuk orang, which untuk benda, that sering bisa menggantikan who/which; whose untuk kepemilikan. Jangan menggandakan pronoun objek.',
'the person who... · the book that... · the girl whose...',
'The woman who lives next door is a doctor.','Wanita yang tinggal di sebelah adalah dokter.',
'The woman who she lives next door is a doctor.','The woman who lives next door is a doctor.','Who sudah menjadi subjek relative clause; jangan tambah she.',[
 c('The man ___ called is my uncle.','who|where|whose',0,'Who merujuk pada orang sebagai subjek.'),
 f('Lengkapi: This is the book ___ I bought.','that|which','That atau which dapat merujuk ke benda pada defining clause.'),
 c('Which relative pronoun expresses possession?','whose|where|when',0,'Whose menunjukkan kepemilikan.')])
add('B1','Passive Voice: Basic','Fokus pada tindakan',
'Passive voice digunakan ketika yang menerima aksi lebih penting atau pelaku tidak diketahui. Bentuk dasar: be + past participle; tense pada be menyesuaikan waktu. Pelaku bisa dikenalkan dengan by.',
'is/are + V3 · was/were + V3',
'The window was broken yesterday.','Jendela itu dipecahkan kemarin.',
'The window was broke yesterday.','The window was broken yesterday.','Passive memakai V3 broken, bukan V2 broke.',[
 c('English ___ spoken in many countries.','is|are|does',0,'English (bahasa) tunggal: is spoken.'),
 f('Lengkapi: The letters were ___ yesterday. (send)','sent','V3 dari send adalah sent.'),
 c('Passive of "They clean the room" is...','The room is cleaned.|The room cleaned.|The room has clean.',0,'Present Simple Passive = is/are + V3.')])
add('B1','Reported Speech: Statements','Melaporkan ucapan',
'Reported speech melaporkan ucapan tanpa kutipan langsung. Setelah reporting verb lampau, tense kerap bergeser ke belakang (am→was, will→would); perubahan tidak selalu wajib jika fakta masih berlaku.',
'She said (that) ... · will → would · am → was',
'He said that he was tired.','Dia mengatakan bahwa dia lelah.',
'He said that he is tired yesterday.','He said that he was tired yesterday.','Dengan konteks kemarin, was sesuai urutan pelaporan lampau.',[
 c('She said, "I will call." → She said she ___ call.','will|would|can',1,'Will lazim bergeser menjadi would.'),
 f('Lengkapi: He said he ___ busy. (am → lampau)','was','Am dalam pelaporan lampau bergeser menjadi was.'),
 c('Which is a reporting verb?','said|many|under',0,'Said merupakan bentuk lampau dari say.')])
add('B1','Conjunctions & Contrast','Menghubungkan gagasan',
'Although + clause dan despite + noun/gerund mengungkap kontras. Because + clause, because of + noun/gerund mengungkap sebab. Bentuk frasa sesudah konektor penting.',
'although + S V · despite + noun/-ing · because of + noun',
'Although it was raining, we went out.','Meskipun hujan, kami tetap pergi.',
'Despite it was raining, we went out.','Although it was raining, we went out.','Despite tidak langsung diikuti clause; although bisa.',[
 c('___ the rain, we played outside.','Although|Despite|Because',1,'Despite diikuti noun phrase the rain.'),
 f('Lengkapi: We stayed home ___ it was raining.','because','Because diikuti clause it was raining.'),
 c('Which is correct?','despite being tired|despite she was tired|although the rain',0,'Despite diikuti gerund being tired.')])

# B2 — upper intermediate
add('B2','Past Perfect Continuous','Durasi sebelum titik lampau',
'Past Perfect Continuous menekankan lama aktivitas yang berlangsung sebelum suatu titik di masa lampau. Sering menyatakan sebab akibat: orang kelelahan karena telah berlari.',
'had been + V-ing · for/since + time',
'She had been working for hours before she rested.','Dia sudah bekerja berjam-jam sebelum beristirahat.',
'She had working for hours before she rested.','She had been working for hours before she rested.','Past Perfect Continuous memerlukan had been + -ing.',[
 c('They ___ been waiting for an hour when it arrived.','have|had|were',1,'Had been + -ing adalah Past Perfect Continuous.'),
 f('Lengkapi: He had been ___ all night. (study)','studying','Been + -ing: studying.'),
 c('Focus of Past Perfect Continuous?','duration before past event|future certainty|general habits',0,'Struktur ini menekankan durasi sebelum titik lampau.')])
add('B2','Third & Mixed Conditionals','Penyesalan masa lalu',
'Third Conditional membayangkan hasil berbeda untuk masa lalu yang tidak terjadi. Mixed Conditional mengaitkan kondisi masa lalu yang tidak nyata dengan akibat sekarang atau sebaliknya.',
'If + had + V3, would have + V3 · If + had V3, would + V1',
'If I had studied, I would have passed.','Jika dahulu saya belajar, saya pasti sudah lulus.',
'If I had studied, I would passed.','If I had studied, I would have passed.','Third Conditional membutuhkan would have + V3.',[
 c('If she had left early, she ___ caught the train.','would have|will have|would',0,'Hasil tidak nyata masa lalu: would have + V3.'),
 f('Lengkapi: If I had known, I would have ___. (help)','helped','Would have + V3 helped.'),
 c('Which conditional is about an unreal past?','third|zero|first',0,'Third Conditional berkaitan dengan masa lalu yang tidak terjadi.')])
add('B2','Past Modals: Deduction & Regret','Modal + have + V3',
'Must have + V3 menyatakan dugaan kuat tentang masa lalu; might have + V3 kemungkinan; can’t have + V3 ketidakmungkinan; should have + V3 penyesalan atau kritik.',
'must/might/can’t/should + have + V3',
'She must have forgotten the meeting.','Dia pasti telah lupa rapat itu.',
'She must has forgotten the meeting.','She must have forgotten the meeting.','Setelah modal must, gunakan have (bukan has).',[
 c('I ___ have called you. I’m sorry.','should|can|must not',0,'Should have menyatakan penyesalan atas sesuatu yang tidak dilakukan.'),
 f('Lengkapi: He might have ___ the bus. (miss)','missed','Might have diikuti past participle missed.'),
 c('A strong deduction about the past uses...','must have + V3|must + V2|must has + V3',0,'Must have + V3 mengungkap kesimpulan kuat.')])
add('B2','Advanced Passive Voice','Passive lintas tense',
'Passive dapat dipakai dalam Perfect, Continuous, dan modal. Bentuk utama mempertahankan be + V3: has been repaired, is being repaired, must be repaired.',
'has been + V3 · is being + V3 · must be + V3',
'The road is being repaired now.','Jalan itu sedang diperbaiki sekarang.',
'The road is being repair now.','The road is being repaired now.','Aksi perbaikan sedang berlangsung: is being repaired.',[
 c('The package has ___ delivered.','be|been|being',1,'Present Perfect Passive memakai has been + V3.'),
 f('Lengkapi: The work must be ___ today. (finish)','finished','Modal Passive: must be + past participle.'),
 c('Ongoing passive action uses...','is being checked|has check|is been checking',0,'Present Continuous Passive = is being + V3.')])
add('B2','Non-defining Relative Clauses','Informasi tambahan',
'Non-defining clauses menambah informasi yang tidak penting untuk identifikasi. Gunakan koma; who/which/whose dapat dipakai, tetapi that umumnya tidak boleh menggantikan relative pronoun di sini.',
'My sister, who lives in Bali, ... · The phone, which ...',
'My car, which is ten years old, still works.','Mobilku, yang sudah berumur sepuluh tahun, masih berfungsi.',
'My car, that is ten years old, still works.','My car, which is ten years old, still works.','Dalam non-defining relative clause dengan koma, gunakan which, bukan that.',[
 c('My brother, ___ is a doctor, lives here.','that|who|where',1,'Who cocok untuk orang dalam non-defining clause.'),
 f('Lengkapi: Jakarta, ___ is Indonesia’s capital, is busy.','which','Which menambahkan informasi tentang tempat sebagai noun.'),
 c('Non-defining clauses are usually set off by...','commas|question marks|slashes',0,'Klausa tambahan dipisahkan dengan koma.')])
add('B2','Wish & If Only','Harapan berlawanan fakta',
'Wish/if only + past simple mengungkap situasi kini yang diinginkan berbeda; + past perfect untuk penyesalan lampau. Wish + would bisa menyatakan keinginan perubahan perilaku atau kondisi.',
'I wish + past · I wish + had V3 · I wish + would V1',
'I wish I knew the answer.','Andai saja saya tahu jawabannya.',
'I wish I know the answer.','I wish I knew the answer.','Keinginan yang bertentangan dengan fakta sekarang memakai past form.',[
 c('I wish I ___ studied harder last year.','have|had|will',1,'Penyesalan lampau: wish + had + V3.'),
 f('Lengkapi: If only I ___ taller!','were|was','Were umum untuk situasi hipotetis dengan I; was juga dipakai informal.'),
 c('Present unreal wish:','I wish I had more time.|I wish I have more time.|I wish I will had time.',0,'Untuk situasi kini yang tidak nyata gunakan past form.')])
add('B2','Causative Have & Get','Meminta orang lain melakukan sesuatu',
'Causative menyatakan kita mengatur pekerjaan supaya dilakukan orang lain. Have/get + object + V3 menekankan hasil layanan. Get + someone + to V1 dan have + someone + V1 menekankan pelaku.',
'have/get + object + V3 · get + person + to V1',
'I had my phone repaired.','Saya menyuruh orang memperbaiki ponsel saya.',
'I had my phone repair.','I had my phone repaired.','Causative have + object + past participle = repaired.',[
 c('She got her hair ___.','cut|to cut|cutting',0,'Got + object + V3; cut sama untuk V1/V2/V3.'),
 f('Lengkapi: We had the house ___. (paint)','painted','Have + object + V3 painted.'),
 c('Which means a mechanic did it for you?','I had my car fixed.|I fixed a car yesterday.|I have fixing my car.',0,'Have something done mengindikasikan jasa orang lain.')])
add('B2','Reporting Verbs & Indirect Questions','Pelaporan lanjutan',
'Reporting verbs memiliki pola berbeda: suggest + -ing/that clause, advise someone to V1, deny + -ing. Indirect questions menggunakan urutan subjek lalu verb, bukan inversi pertanyaan langsung.',
'advise + object + to V1 · suggest + V-ing · asked where he lived',
'She asked me where I lived.','Dia bertanya di mana saya tinggal.',
'She asked me where did I live.','She asked me where I lived.','Dalam indirect question, urutan menjadi subject + verb.',[
 c('He suggested ___ earlier.','leave|leaving|to leaving',1,'Suggest diikuti -ing dalam pola ini.'),
 f('Lengkapi: She advised me ___ rest.','to','Advise + object + to-infinitive.'),
 c('Which is an indirect question?','Could you tell me where he lives?|Could you tell me where does he live?|Where does he lives?',0,'Urutan setelah where adalah he lives.')])
add('B2','Phrasal Verbs & Collocations','Ungkapan alami',
'Phrasal verb terdiri dari verb + particle dan maknanya terkadang idiomatis. Collocation adalah pasangan kata yang sering muncul bersama, seperti make a decision, do homework, take a break.',
'give up · look after · put off · make a decision',
'She gave up smoking.','Dia berhenti merokok.',
'She gave up to smoke.','She gave up smoking.','Give up diikuti noun atau gerund.',[
 c('Which means "menunda"?','put off|look after|run into',0,'Put off berarti menunda.'),
 f('Lengkapi: Please ___ a decision soon.','make','Collocation baku: make a decision.'),
 c('Choose the natural collocation.','do homework|make homework|take homework',0,'Bahasa Inggris memakai do homework.')])

# C1 — advanced / academically useful
add('C1','Negative Inversion','Penekanan formal',
'Adverbial negatif/restriktif di awal kalimat dapat memicu inversi auxiliary-subject: Never have I..., Rarely do we..., Not only did she... . Jika auxiliary belum ada, gunakan do/does/did.',
'Never + aux + subject + verb · Rarely + do/does + subject + V1',
'Never have I seen such a view.','Belum pernah saya melihat pemandangan seperti itu.',
'Never I have seen such a view.','Never have I seen such a view.','Never di awal memicu inversi have + I.',[
 c('Rarely ___ he make mistakes.','does|is|has',0,'Present Simple dengan he membutuhkan does untuk inversi.'),
 f('Lengkapi: Never ___ I felt so relieved.','have','Present Perfect inversion: Never have I felt...'),
 c('Which is a formal inversion?','Hardly had I arrived when it began.|Hardly I had arrived when it began.|I hardly had arrived when it began.',0,'Hardly ... when lazim memakai inverted had + subject.')])
add('C1','Cleft Sentences & Emphasis','Fokus informasi',
'Cleft sentence memindahkan fokus agar bagian tertentu menjadi penekanan: It was John who called; What I need is rest. Bentuk ini banyak dipakai untuk mengontraskan informasi.',
'It was X that/who ... · What ... is ...',
'It was Maria who solved the problem.','Maria-lah yang menyelesaikan masalah itu.',
'It was Maria which solved the problem.','It was Maria who solved the problem.','Who lebih tepat untuk orang dalam it-cleft.',[
 c('___ I need is some quiet time.','What|Which|Who',0,'What-cleft: What I need is...'),
 f('Lengkapi: It ___ yesterday that she called.','was','It was + fokus waktu + that...'),
 c('What is emphasized in "It was Tom who paid"?','Tom|paid|no one',0,'Bagian setelah It was mendapat fokus.')])
add('C1','Reduced Relatives & Participle Clauses','Klausa ringkas',
'Relative clause bisa dipendekkan menjadi -ing untuk makna aktif atau V3 untuk makna pasif. Participle clause menghubungkan aksi dengan subjek yang sama; hindari dangling modifiers.',
'the man standing there · the report written yesterday',
'The people waiting outside are students.','Orang-orang yang menunggu di luar adalah pelajar.',
'The people waited outside are students.','The people waiting outside are students.','Participle aktif dalam reduced relative memakai -ing.',[
 c('The documents ___ yesterday are confidential.','signing|signed|sign',1,'Documents menerima aksi penandatanganan: signed.'),
 f('Lengkapi: The woman ___ by the door is my aunt. (stand)','standing','Reduced active relative menggunakan standing.'),
 c('Reduced passive relative usually uses...','past participle|simple past finite verb|will + base',0,'V3 dapat menggantikan who/which + be + V3.')])
add('C1','Nominalisation','Gaya akademik',
'Nominalisation mengubah verb/adjective menjadi noun untuk kepadatan informasi dan gaya formal. Misalnya decide→decision, improve→improvement, accurate→accuracy. Gunakan seperlunya agar kalimat tetap jelas.',
'decide → decision · investigate → investigation',
'The investigation revealed new evidence.','Penyelidikan itu mengungkap bukti baru.',
'The investigate revealed new evidence.','The investigation revealed new evidence.','Setelah the dibutuhkan noun investigation.',[
 c('Noun form of "decide" is...','decidingly|decision|decisive',1,'Decision adalah noun dari decide.'),
 f('Lengkapi: Their ___ was unexpected. (arrive)','arrival','Arrival adalah nominalisasi dari arrive.'),
 c('Which sentence uses nominalisation?','The improvement was significant.|Things improved significantly.|They improve often.',0,'Improvement adalah noun abstrak hasil nominalisasi.')])
add('C1','Hedging & Academic Stance','Pernyataan hati-hati',
'Hedging melembutkan klaim saat bukti belum pasti: may, might, appear to, seem to, tend to, suggest that. Bedakan kepastian dari kemungkinan dan hindari klaim mutlak tanpa dukungan.',
'may indicate · appears to suggest · tends to increase',
'The results may indicate a change.','Hasilnya mungkin mengindikasikan perubahan.',
'The results may indicates a change.','The results may indicate a change.','Modal may diikuti base verb indicate.',[
 c('Which sounds appropriately cautious?','This may suggest a pattern.|This definitely proves everything.|All people always agree.',0,'May suggest menandakan klaim sementara.'),
 f('Lengkapi: The data seem ___ support the hypothesis.','to','Seem + to-infinitive.'),
 c('Which modal expresses possibility?','might|must|shall (formal obligation)',0,'Might menandakan kemungkinan.')])
add('C1','Subjunctive & Formal Recommendations','Struktur formal',
'Dalam formal mandative subjunctive setelah insist, suggest, recommend, essential that, verb tetap dalam base form meski subjek he/she/it. Dalam bahasa Inggris British juga sering digunakan should + base verb.',
'It is essential that she be... · They recommend that he go...',
'The committee recommended that he attend.','Komite merekomendasikan agar dia hadir.',
'The committee recommended that he attends.','The committee recommended that he attend.','Mandative subjunctive memakai base verb attend.',[
 c('It is vital that everyone ___ informed.','be|is|are',0,'Formal subjunctive mempertahankan base form be.'),
 f('Lengkapi: They insisted that she ___ on time. (arrive)','arrive','Subjunctive: she arrive, tanpa -s.'),
 c('Which is a mandative subjunctive?','It is necessary that he be ready.|It is necessary that he is be ready.|It is necessary he being ready.',0,'He be adalah bentuk mandative subjunctive.')])
add('C1','Cohesion & Advanced Discourse Markers','Alur argumen',
'Gunakan konektor untuk memandu argumen: nevertheless (kontras), moreover/furthermore (penambahan), consequently (akibat), whereas (perbandingan kontras). Perhatikan punctuation dan logika.',
'claim; nevertheless, counterpoint · cause; consequently, result',
'The plan was risky; nevertheless, it succeeded.','Rencana itu berisiko; meskipun demikian, berhasil.',
'The plan was risky; moreover, it succeeded.','The plan was risky; nevertheless, it succeeded.','Hubungan yang tepat adalah kontras, bukan penambahan.',[
 c('Sales fell; ___, profits declined.','consequently|nevertheless|whereas',0,'Consequently menandakan akibat.'),
 f('Lengkapi: It was expensive; ___, we bought it. (meskipun begitu)','nevertheless|nonetheless','Nevertheless/Nonetheless menunjukkan kontras.'),
 c('Which marker adds another point?','furthermore|however|despite',0,'Furthermore menambahkan argumen.')])
add('C1','Future Continuous & Future Perfect','Aspek waktu lanjut',
'Future Continuous menyoroti aksi yang sedang berlangsung pada titik masa depan: will be + -ing. Future Perfect menekankan aksi yang telah selesai sebelum batas masa depan: will have + V3.',
'will be + V-ing · will have + V3 · by + future deadline',
'By Friday, I will have finished the report.','Pada hari Jumat, saya sudah akan menyelesaikan laporan.',
'By Friday, I will have finish the report.','By Friday, I will have finished the report.','Will have diikuti V3 finished.',[
 c('At 8 PM, I ___ be studying.','will|have|had',0,'Future Continuous: will be + -ing.'),
 f('Lengkapi: By noon, she will have ___ it. (complete)','completed','Future Perfect memakai have + V3 completed.'),
 c('Which describes an action in progress tomorrow?','will be working|will have worked|worked yesterday',0,'Will be working berarti sedang bekerja pada waktu masa depan.')])
add('C1','Ellipsis, Substitution & Register','Kealamian bahasa',
'Ellipsis menghilangkan bagian yang sudah jelas; substitution memakai one/ones, so, do so, neither untuk mencegah pengulangan. Pilihan register penting: gonna cocok informal, going to untuk tulisan formal.',
'I think so · Neither do I · the red one',
'I prefer the blue one.','Saya lebih suka yang biru.',
'I prefer blue the one.','I prefer the blue one.','Untuk satu objek yang dimaksud gunakan one, bukan ones.',[
 c('She likes jazz, and ___ do I.','so|neither|either',0,'So do I berarti saya juga menyukainya.'),
 f('Lengkapi: I don’t think ___.','so','Think so merupakan substitusi clause.'),
 c('Which is more appropriate in formal writing?','going to|gonna|wanna',0,'Going to lebih cocok dalam register formal.')])

levels = [dict(id='A1',name='Foundation',subtitle='Bangun dasar bahasa Inggris',shade='#745CDB'),
          dict(id='A2',name='Elementary',subtitle='Ceritakan rutinitas, masa lalu, dan rencana',shade='#16A6A0'),
          dict(id='B1',name='Intermediate',subtitle='Hubungkan ide dan pengalaman',shade='#E58B49'),
          dict(id='B2',name='Upper Intermediate',subtitle='Tulis dan berbicara lebih presisi',shade='#3C82C5'),
          dict(id='C1',name='Advanced',subtitle='Gunakan struktur kompleks dengan natural',shade='#9B5C94')]
assert len(lessons)==45, len(set(x['id'] for x in lessons))==45
assert all(len(x['questions'])==4 for x in lessons)
for x in lessons:
    for q in x['questions']:
        assert q['answer'] and q['explanation'] and q['prompt']
        assert q['type']!='choice' or (q['answer'] in q['options'] and len(set(q['options']))==len(q['options']))
        assert q['type']!='input' or q['answer'] in q['accepted']
path=os.path.join(os.path.dirname(__file__),'app/src/main/assets/curriculum.json')
with open(path,'w',encoding='utf-8') as fp:
    json.dump(dict(version=1,levels=levels,lessons=lessons),fp,ensure_ascii=False,indent=2)
print(f'{len(lessons)} lessons, {sum(len(x["questions"]) for x in lessons)} exercises, {os.path.getsize(path)} bytes')
